package com.example.usertest

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
