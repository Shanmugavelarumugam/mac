import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:usertest/login/auth.dart';
import 'package:usertest/login/login.dart';
import 'package:usertest/widgets/inputfield.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final userController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final phoneController = TextEditingController();

  final ValueNotifier<bool> isLoading = ValueNotifier(false);
  final ValueNotifier<bool> obscurePassword = ValueNotifier(true);

  bool isValidEmail(String email) {
    final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    return emailRegex.hasMatch(email);
  }

  void _register() async {
    final username = userController.text.trim();
    final email = emailController.text.trim();
    final password = passwordController.text.trim();
    final phone = phoneController.text.trim();

    print('Register button pressed');
    print('Input - username: $username, email: $email, phone: $phone');

    if ([username, email, password, phone].any((e) => e.isEmpty)) {
      print('Validation failed: some fields are empty');
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Please fill all fields")));
      return;
    }

    if (!isValidEmail(email)) {
      print('Validation failed: invalid email format');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter a valid email address")),
      );
      return;
    }

    isLoading.value = true;
    print('Starting API register call...');

    try {
      final result = await ApiService.register({
        'username': username,
        'email': email,
        'phone': phone,
        'password': password,
      });

      print('API response: $result');

      if (result['success']) {
        print('Registration successful, navigating to login screen');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Registration Successful")),
        );
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const LoginScreen()),
        );
      } else {
        print('Registration failed with message: ${result['message']}');
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(result['message'])));
      }
    } catch (e) {
      print('Exception caught during registration: $e');
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text("Error: $e")));
    } finally {
      isLoading.value = false;
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            double screenWidth = constraints.maxWidth;
            double padding = screenWidth > 600 ? 40 : 20;

            return Padding(
              padding: EdgeInsets.all(padding),
              child: ListView(
                children: [
                  Image.asset('assets/rka.png', height: 70, width: 80),
                  const SizedBox(height: 30),
                  const Text(
                    "Register",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Color.fromARGB(255, 219, 109, 6),
                    ),
                  ),
                  const SizedBox(height: 20),
                  CustomTextField(
                    label: "User name",
                    icon: Icons.person,
                    controller: userController,
                    textInputAction: TextInputAction.next,
                  ),
                  CustomTextField(
                    label: "Email id",
                    icon: Icons.email,
                    controller: emailController,
                    textInputAction: TextInputAction.next,
                  ),
                  CustomTextField(
                    label: "Phone number",
                    icon: Icons.phone,
                    controller: phoneController,
                    textInputAction: TextInputAction.next,
                  ),
                  ValueListenableBuilder<bool>(
                    valueListenable: obscurePassword,
                    builder: (context, obscure, _) {
                      return CustomTextField(
                        label: "Password",
                        icon: Icons.lock,
                        textInputAction: TextInputAction.next,

                        controller: passwordController,
                        obscureText: obscure,
                        suffixIcon: IconButton(
                          icon: Icon(
                            obscure ? Icons.visibility_off : Icons.visibility,
                          ),
                          onPressed: () {
                            obscurePassword.value = !obscurePassword.value;
                          },
                        ),
                      );
                    },
                  ),
                  const SizedBox(height: 20),
                  ValueListenableBuilder<bool>(
                    valueListenable: isLoading,
                    builder: (context, loading, _) {
                      return loading
                          ? const Center(child: CircularProgressIndicator())
                          : ElevatedButton(
                            onPressed: _register,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color.fromARGB(
                                255,
                                219,
                                109,
                                6,
                              ),
                            ),
                            child: const Text(
                              "Register",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          );
                    },
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const LoginScreen(),
                        ),
                      );
                    },
                    child: const Center(
                      child: Text("Already have an account? Login"),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
