import 'package:flutter/material.dart';

class EducationScreen extends StatefulWidget {
  const EducationScreen({super.key});

  @override
  State<EducationScreen> createState() => _EducationScreenState();
}

class _EducationScreenState extends State<EducationScreen> {
  final List<String> educationLevels = [
    '10th',
    '12th',
    'UG',
    'PG',
    'Ph.D',
    'Diploma',
  ];

  final List<String> educationOptions = [
    'BA',
    'BSc',
    'B.Com',
    'BE (Computer Science)',
    'ME',
    'MBA',
    'MCA',
    'Ph.D (Astrology)',
    'Diploma (Electronics)',
    'Other',
  ];

  final List<EducationEntry> educationEntries = [];

  @override
  void initState() {
    super.initState();
    // Pre-fill levels
    for (var level in educationLevels) {
      educationEntries.add(EducationEntry(level));
    }
  }

  @override
  void dispose() {
    for (var entry in educationEntries) {
      entry.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('கல்வி விவரங்கள்'),
        backgroundColor: Colors.deepOrange,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text(
              'Add all your previous education details',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: educationEntries.length,
                itemBuilder: (context, index) {
                  final entry = educationEntries[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            entry.level,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            controller: entry.dateController,
                            decoration: const InputDecoration(
                              labelText: 'Completed Date',
                              border: OutlineInputBorder(),
                            ),
                          ),
                          const SizedBox(height: 10),
                          DropdownButtonFormField<String>(
                            value: entry.selectedDegree,
                            decoration: const InputDecoration(
                              labelText: 'Degree / Course',
                              border: OutlineInputBorder(),
                            ),
                            items:
                                educationOptions.map((edu) {
                                  return DropdownMenuItem(
                                    value: edu,
                                    child: Text(edu),
                                  );
                                }).toList(),
                            onChanged: (value) {
                              setState(() {
                                entry.selectedDegree = value!;
                              });
                            },
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            controller: entry.commentController,
                            decoration: const InputDecoration(
                              labelText: 'Comment',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 10),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Back'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/health');
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                  ),
                  child: const Text('Next'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class EducationEntry {
  final String level;
  String? selectedDegree;
  final TextEditingController dateController = TextEditingController();
  final TextEditingController commentController = TextEditingController();

  EducationEntry(this.level);

  void dispose() {
    dateController.dispose();
    commentController.dispose();
  }
}
