import 'package:flutter/material.dart';

class MarriageScreen extends StatefulWidget {
  const MarriageScreen({super.key});

  @override
  State<MarriageScreen> createState() => _MarriageScreenState();
}

class _MarriageScreenState extends State<MarriageScreen> {
  String selectedMarriage = '1st Marriage';
  final List<String> marriageTypes = [
    '1st Marriage',
    '2nd Marriage',
    '3rd Marriage',
    '4th Marriage',
  ];

  final TextEditingController firstMarriageDateController =
      TextEditingController();
  final TextEditingController secondMarriageDateController =
      TextEditingController();
  final TextEditingController muruthamTimeController = TextEditingController();

  @override
  void dispose() {
    firstMarriageDateController.dispose();
    secondMarriageDateController.dispose();
    muruthamTimeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('மணவாழ்க்கை விவரங்கள்'),
        centerTitle: true,
        automaticallyImplyLeading: true, // iOS-style back button
        elevation: 4,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.deepOrange, Colors.orangeAccent],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Card(
          elevation: 10,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "💍 Marriage Details",
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),

                _buildDropdown(),

                if (selectedMarriage != '1st Marriage') ...[
                  const SizedBox(height: 20),
                  _buildDatePickerField(
                    label: '1st Marriage Date',
                    controller: firstMarriageDateController,
                  ),
                ],

                if (selectedMarriage == '3rd Marriage' ||
                    selectedMarriage == '4th Marriage') ...[
                  const SizedBox(height: 20),
                  _buildDatePickerField(
                    label: '2nd Marriage Date',
                    controller: secondMarriageDateController,
                  ),
                ],

                const SizedBox(height: 20),
                _buildTimePickerField(
                  label: 'Murutham Time',
                  controller: muruthamTimeController,
                ),

                const SizedBox(height: 30),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.arrow_back_ios),
                      label: const Text('Back'),
                    ),
                    ElevatedButton.icon(
                      onPressed: () {
                        Navigator.pushNamed(context, '/job');
                      },
                      icon: const Icon(Icons.arrow_forward_ios),
                      label: const Text('Next'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.deepOrange,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 24,
                          vertical: 14,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDropdown() {
    return DropdownButtonFormField<String>(
      value: selectedMarriage,
      decoration: InputDecoration(
        labelText: 'Marriage Type',
        prefixIcon: const Icon(Icons.favorite),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.deepOrange, width: 2),
        ),
      ),
      items:
          marriageTypes
              .map((type) => DropdownMenuItem(value: type, child: Text(type)))
              .toList(),
      onChanged: (value) {
        setState(() {
          selectedMarriage = value!;
        });
      },
    );
  }

  Widget _buildDatePickerField({
    required String label,
    required TextEditingController controller,
  }) {
    return TextFormField(
      controller: controller,
      readOnly: true,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: const Icon(Icons.calendar_today),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.deepOrange, width: 2),
        ),
      ),
      onTap: () async {
        DateTime? picked = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime(1900),
          lastDate: DateTime.now(),
        );
        if (picked != null) {
          controller.text =
              "${picked.day.toString().padLeft(2, '0')}-${picked.month.toString().padLeft(2, '0')}-${picked.year}";
        }
      },
    );
  }

  Widget _buildTimePickerField({
    required String label,
    required TextEditingController controller,
  }) {
    return TextFormField(
      controller: controller,
      readOnly: true,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: const Icon(Icons.access_time),
        suffixIcon:
            controller.text.isNotEmpty
                ? IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () => setState(() => controller.clear()),
                )
                : null,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.deepOrange, width: 2),
        ),
      ),
      onTap: () async {
        TimeOfDay? pickedTime = await showTimePicker(
          context: context,
          initialTime: TimeOfDay.now(),
        );
        if (pickedTime != null) {
          final formattedTime = pickedTime.format(context);
          setState(() {
            controller.text = formattedTime;
          });
        }
      },
    );
  }
}