import 'package:flutter/material.dart';

class JobScreen extends StatefulWidget {
  const JobScreen({super.key});

  @override
  State<JobScreen> createState() => _JobScreenState();
}

class _JobScreenState extends State<JobScreen> {
  final List<String> jobOptions = [
    'Software Developer',
    'Teacher',
    'Doctor',
    'Police',
    'Engineer',
    'Business',
    'Driver',
    'Farmer',
    'Accountant',
    'Nurse',
    'Electrician',
    'Designer',
    'Architect',
    'Lawyer',
    'Other',
  ];

  String? currentJob;
  final List<JobEntry> jobHistory = [];

  void addJobEntry() {
    setState(() {
      jobHistory.add(JobEntry());
    });
  }

  void removeJobEntry(int index) {
    setState(() {
      jobHistory.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('வேலை விவரங்கள்'),
        backgroundColor: Colors.deepOrange,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(
                labelText: 'Current Job',
                border: OutlineInputBorder(),
              ),
              value: currentJob,
              items:
                  jobOptions.map((job) {
                    return DropdownMenuItem(value: job, child: Text(job));
                  }).toList(),
              onChanged: (value) {
                setState(() {
                  currentJob = value;
                });
              },
            ),
            const SizedBox(height: 20),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Previous Jobs',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
                ElevatedButton.icon(
                  onPressed: addJobEntry,
                  icon: const Icon(Icons.add),
                  label: const Text('Add Job'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            Expanded(
              child: ListView.builder(
                itemCount: jobHistory.length,
                itemBuilder: (context, index) {
                  final jobEntry = jobHistory[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        children: [
                          TextFormField(
                            controller: jobEntry.dateController,
                            decoration: const InputDecoration(
                              labelText: 'Start Date',
                              border: OutlineInputBorder(),
                            ),
                          ),
                          const SizedBox(height: 10),
                          DropdownButtonFormField<String>(
                            value: jobEntry.selectedJob,
                            decoration: const InputDecoration(
                              labelText: 'Job Title',
                              border: OutlineInputBorder(),
                            ),
                            items:
                                jobOptions.map((job) {
                                  return DropdownMenuItem(
                                    value: job,
                                    child: Text(job),
                                  );
                                }).toList(),
                            onChanged: (value) {
                              setState(() {
                                jobEntry.selectedJob = value!;
                              });
                            },
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            controller: jobEntry.commentController,
                            decoration: const InputDecoration(
                              labelText: 'Comment',
                              border: OutlineInputBorder(),
                            ),
                          ),
                          const SizedBox(height: 10),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(
                              onPressed: () => removeJobEntry(index),
                              icon: const Icon(Icons.delete, color: Colors.red),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 10),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                OutlinedButton(
                  onPressed: () {
                    Navigator.pop(context); // Back to Marriage screen
                  },
                  child: const Text('Back'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/education');
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                  ),
                  child: const Text('Next'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class JobEntry {
  final TextEditingController dateController = TextEditingController();
  String? selectedJob;
  final TextEditingController commentController = TextEditingController();

  void dispose() {
    dateController.dispose();
    commentController.dispose();
  }
}
