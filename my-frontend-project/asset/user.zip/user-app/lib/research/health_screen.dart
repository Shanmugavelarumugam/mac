import 'package:flutter/material.dart';

class HealthScreen extends StatefulWidget {
  const HealthScreen({super.key});

  @override
  State<HealthScreen> createState() => _HealthScreenState();
}

class _HealthScreenState extends State<HealthScreen> {
  final List<String> healthOptions = [
    'Heart Attack',
    'Eye Problem',
    'Leg Surgery',
    'Appendix Operation',
    'Diabetes',
    'Asthma',
    'Blood Pressure',
    'Kidney Stone',
    'Other',
  ];

  final List<HealthEntry> healthEntries = [HealthEntry()];

  void addEntry() {
    setState(() {
      healthEntries.add(HealthEntry());
    });
  }

  void removeEntry(int index) {
    setState(() {
      healthEntries.removeAt(index);
    });
  }

  @override
  void dispose() {
    for (var entry in healthEntries) {
      entry.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('மருத்துவ விவரங்கள்'),
        backgroundColor: Colors.deepOrange,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text(
              'Add all your health history',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: healthEntries.length,
                itemBuilder: (context, index) {
                  final entry = healthEntries[index];
                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Issue ${index + 1}',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            controller: entry.dateController,
                            decoration: const InputDecoration(
                              labelText: 'Date of Issue',
                              border: OutlineInputBorder(),
                            ),
                          ),
                          const SizedBox(height: 10),
                          DropdownButtonFormField<String>(
                            value: entry.selectedIssue,
                            decoration: const InputDecoration(
                              labelText: 'Health Problem',
                              border: OutlineInputBorder(),
                            ),
                            items:
                                healthOptions.map((issue) {
                                  return DropdownMenuItem(
                                    value: issue,
                                    child: Text(issue),
                                  );
                                }).toList(),
                            onChanged: (value) {
                              setState(() {
                                entry.selectedIssue = value!;
                              });
                            },
                          ),
                          const SizedBox(height: 10),
                          TextFormField(
                            controller: entry.commentController,
                            decoration: const InputDecoration(
                              labelText: 'Comment',
                              border: OutlineInputBorder(),
                            ),
                          ),
                          if (healthEntries.length > 1)
                            Align(
                              alignment: Alignment.centerRight,
                              child: IconButton(
                                icon: const Icon(
                                  Icons.delete,
                                  color: Colors.red,
                                ),
                                onPressed: () => removeEntry(index),
                              ),
                            ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            Row(
              children: [
                ElevatedButton.icon(
                  onPressed: addEntry,
                  icon: const Icon(Icons.add),
                  label: const Text('Add More'),
                ),
                const Spacer(),
                OutlinedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Back'),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/child');
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                  ),
                  child: const Text('Next'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class HealthEntry {
  String? selectedIssue;
  final TextEditingController dateController = TextEditingController();
  final TextEditingController commentController = TextEditingController();

  void dispose() {
    dateController.dispose();
    commentController.dispose();
  }
}
