// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';

// class HorizontalDropdowns extends StatefulWidget {
//   @override
//   _HorizontalDropdownsState createState() => _HorizontalDropdownsState();
// }

// class _HorizontalDropdownsState extends State<HorizontalDropdowns> {
//   final ValueNotifier<String> _selectedLagnam = ValueNotifier('மேஷம் லக்னம்');
//   final ValueNotifier<String> _selectedBhavam = ValueNotifier('முதல் பாவம்');
//   final ValueNotifier<String> _selectedPlanet = ValueNotifier('சூரியன்');
//   final ValueNotifier<String> _selectedStar = ValueNotifier('அசுவினி');
//   final ValueNotifier<String> _selectedRasi = ValueNotifier('மேஷம்');
//   ValueNotifier<String> _twocombination = ValueNotifier('சூரி+ சந்');
 
//   // Dropdown lists
//   final List<String> lagnamList = ['மேஷம் லக்னம்', 'ரிஷபம் லக்னம்', 'மிதுனம் லக்னம்', 'கடகம் லக்னம்', 'சிம்மம் லக்னம்', 'கன்னி லக்னம்', 'துலாம் லக்னம்', 'விருச்சிகம் லக்னம்', 'தனுசு லக்னம்', 'மகரம் லக்னம்', 'கும்பம் லக்னம்', 'மீனம் லக்னம்'];
//   final List<String> bhavamList = ['முதல் பாவம்','இரண்டாம் பாவம்','மூன்றாம் பாவம்','நான்காம் பாவம்','ஐந்தாம் பாவம்','ஆறாம் பாவம்','ஏழாம் பாவம்','எட்டாம் பாவம்','ஒன்பதாம் பாவம்','பத்தாம் பாவம்','பதினொன்றாம் பாவம்','பன்னிரண்டாம் பாவம்'];
//   final List<String> planetList = ['சூரியன்', 'சந்திரன்', 'செவ்வாய்', 'புதன்', 'குரு', 'சுக்ரன்', 'சனி', 'ராகு', 'கேது',];
//   final List<String> starList = ["அசுவினி", "பரணி", "கார்த்திகை", "ரோகிணி", "மிருகசீரிடம்", "திருவாதிரை", "புனர்பூசம்", "பூசம்", "ஆயில்யம்", "மகம்", "பூரம்", "உத்திரம்", "ஹஸ்தம்", "சித்திரை", "சுவாதி", "விசாகம்", "அனுஷம்", "கேட்டை", "மூலம்", "பூராடம்", "உத்திராடம்", "திருவோணம்", "அவிட்டம்", "சதயம்", "பூரட்டாதி", "உத்திரட்டாதி", "ரேவதி"];
//   final List<String> rasiList = ['மேஷம்','ரிஷபம்','மிதுனம்','கடகம்','சிம்மம்','கன்னி','துலாம்','விருச்சிகம்','தனுசு','மகரம்', 'கும்பம்','மீனம்',];
//   final List<String> twoplanetCombinations = [ 'சூரி+ சந்', 'சூரி+ செவ்', 'சூரி+ புத', 'சூரி+ குரு', 'சூரி+ சுக்','சூரி+ சனி', 'சூரி+ ரா', 'சூரி+ கே', 'சந் + செவ்', 'சந் + புத','சந் + குரு', 'சந் + சுக்', 'சந் + சனி', 'சந் + ரா', 'சந் + கே', 'செவ் + புத', 'செவ் + குரு', 'செவ் + சுக்', 'செவ் + சனி', 'செவ் + ரா','செவ் + கே', 'புத + குரு', 'புத + சுக்', 'புத + சனி', 'புத + ரா', 'புத + கே', 'குரு + சுக்', 'குரு + சனி', 'குரு + ரா', 'குரு + கே','சுக் + சனி', 'சுக் + ரா', 'சுக் + கே', 'சனி + ரா', 'சனி + கே',];
  

//   // Dropdown builder
//   Widget _buildDropdown(
//     String title,
//     List<String> items,
//     ValueNotifier<String> selectedValue,
//     Color backgroundColor,
//   ) {
//     return ValueListenableBuilder<String>(
//       valueListenable: selectedValue,
//       builder: (context, value, child) {
//         return Container(
//           width: 200,
//           margin: EdgeInsets.symmetric(horizontal: 8),
//           padding: EdgeInsets.symmetric(horizontal: 12),
//           decoration: BoxDecoration(
//             color: backgroundColor,
//             borderRadius: BorderRadius.circular(12),
//           ),
//           child: DropdownButtonHideUnderline(
//             child: DropdownButton<String>(
//               value: value,
//               dropdownColor: backgroundColor,
//               style: TextStyle(color: Colors.white),
//               iconEnabledColor: Colors.white,
//               isExpanded: true,
//               onChanged: (val) {
//                 if (val != null) {
//                   selectedValue.value = val;
//                 }
//               },
//               items:
//                   items
//                       .map(
//                         (item) => DropdownMenuItem(
//                           value: item,
//                           child: Text(
//                             item,
//                             style: TextStyle(color: Colors.white),
//                           ),
//                         ),
//                       )
//                       .toList(),
//             ),
//           ),
//         );
//       },
//     );
//   }

//   //  laganm
//   Widget _buildlaganmTable() {
//     return ValueListenableBuilder<String>(
//       valueListenable: _selectedLagnam,
//       builder: (context, _selectedLagnam, _) {
//         return StreamBuilder<QuerySnapshot>(
//           stream:
//               FirebaseFirestore.instance
//                   .collection('lagnam')
//                   .orderBy('timestamp')
//                   .snapshots(),
//           builder: (context, snapshot) {
//             if (snapshot.hasError) {
//               return Center(child: Text('பிழை: ${snapshot.error}'));
//             }
//             if (!snapshot.hasData) {
//               return Center(child: CircularProgressIndicator());
//             }

//             final docs = snapshot.data!.docs;
//             final filteredDocs =
//                 docs.where((doc) {
//                   final data = doc.data() as Map<String, dynamic>;
//                   final rasi = data['lagnam']?.toString().trim();
//                   return rasi == _selectedLagnam;
//                 }).toList();

//             if (filteredDocs.isEmpty) {
//               return Center(
//                 child: Text("தேர்ந்தெடுக்கப்பட்ட ராசிக்கான குறிப்புகள் இல்லை."),
//               );
//             }

//             return SingleChildScrollView(
//               scrollDirection: Axis.vertical,
//               child: Table(
//                 columnWidths: const {1: FlexColumnWidth()},
//                 border: TableBorder.all(
//                   color: const Color.fromARGB(255, 214, 130, 4),
//                 ),
//                 children: [
//                   TableRow(
//                     decoration: BoxDecoration(
//                       color: const Color.fromARGB(255, 214, 130, 4),
//                     ),
//                     children: [
//                       Center(
//                         child: Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: Text(
//                             _selectedLagnam,
//                             style: TextStyle(
//                               fontWeight: FontWeight.bold,
//                               color: Colors.white,
//                             ),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                   ...filteredDocs.map((doc) {
//                     final data = doc.data() as Map<String, dynamic>;
//                     final notes =
//                         data['notes']?.toString().trim() ?? 'குறிப்பு இல்லை';
//                     return TableRow(
//                       children: [
//                         Padding(
//                           padding: EdgeInsets.all(5),
//                           child: Text(
//                             notes,
//                             style: TextStyle(color: Colors.black),
//                           ),
//                         ),
//                       ],
//                     );
//                   }).toList(),
//                 ],
//               ),
//             );
//           },
//         );
//       },
//     );
//   }

//   //bhavam//
// Widget _builbhavamTable() {
//   return ValueListenableBuilder<String>(
//     valueListenable: _selectedBhavam,
//     builder: (context, _selectedBhavam, _) {
//       return StreamBuilder<QuerySnapshot>(
//         stream: FirebaseFirestore.instance
//             .collection('bhavam')
//             .orderBy('timestamp')
//             .snapshots(),
//         builder: (context, snapshot) {
//           if (snapshot.hasError) {
//             return Center(child: Text('பிழை: ${snapshot.error}'));
//           }
//           if (!snapshot.hasData) {
//             return Center(child: CircularProgressIndicator());
//           }

//           final docs = snapshot.data!.docs;
//           final filteredDocs = docs.where((doc) {
//             final data = doc.data() as Map<String, dynamic>;
//             final rasi = data['bhavam']?.toString().trim().toLowerCase();
//             return rasi == _selectedBhavam.trim().toLowerCase();
//           }).toList();

//           if (filteredDocs.isEmpty) {
//             return Center(
//               child: Text("தேர்ந்தெடுக்கப்பட்ட நட்சத்திரத்திற்கான குறிப்புகள் இல்லை."),
//             );
//           }

//           return SingleChildScrollView(
//             scrollDirection: Axis.vertical,
//             child: Table(
//               columnWidths: const {0: FlexColumnWidth()},
//               border: TableBorder.all(color: Color.fromARGB(255, 214, 130, 4)),
//               children: [
//                 TableRow(
//                   decoration: BoxDecoration(
//                     color: Color.fromARGB(255, 214, 130, 4),
//                   ),
//                   children: [
//                     Padding(
//                       padding: const EdgeInsets.all(8.0),
//                       child: Center(
//                         child: Text(
//                           _selectedBhavam,
//                           style: TextStyle(
//                             fontWeight: FontWeight.bold,
//                             color: Colors.white,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//                 ...filteredDocs.map((doc) {
//                   final data = doc.data() as Map<String, dynamic>;
//                   final notes = data['notes']?.toString().trim() ?? 'குறிப்பு இல்லை';
//                   return TableRow(
//                     children: [
//                       Padding(
//                         padding: EdgeInsets.all(5),
//                         child: Text(
//                           notes,
//                           style: TextStyle(color: Colors.black),
//                         ),
//                       ),
//                     ],
//                   );
//                 }).toList(),
//               ],
//             ),
//           );
//         },
//       );
//     },
//   );
// }

// //planet

// Widget _buildplanetTable() {
//   return ValueListenableBuilder<String>(
//     valueListenable: _selectedPlanet,
//     builder: (context, _selectedPlanet, _) {
//       return StreamBuilder<QuerySnapshot>(
//         stream: FirebaseFirestore.instance
//             .collection('planet')
//             .orderBy('timestamp')
//             .snapshots(),
//         builder: (context, snapshot) {
//           if (snapshot.hasError) {
//             return Center(child: Text('பிழை: ${snapshot.error}'));
//           }
//           if (!snapshot.hasData) {
//             return Center(child: CircularProgressIndicator());
//           }

//           final docs = snapshot.data!.docs;
//           final filteredDocs = docs.where((doc) {
//             final data = doc.data() as Map<String, dynamic>;
//             final rasi = data['planet']?.toString().trim().toLowerCase();
//             return rasi == _selectedPlanet.trim().toLowerCase();
//           }).toList();

//           if (filteredDocs.isEmpty) {
//             return Center(
//               child: Text("தேர்ந்தெடுக்கப்பட்ட நட்சத்திரத்திற்கான குறிப்புகள் இல்லை."),
//             );
//           }

//           return SingleChildScrollView(
//             scrollDirection: Axis.vertical,
//             child: Table(
//               columnWidths: const {0: FlexColumnWidth()},
//               border: TableBorder.all(color: Color.fromARGB(255, 214, 130, 4)),
//               children: [
//                 TableRow(
//                   decoration: BoxDecoration(
//                     color: Color.fromARGB(255, 214, 130, 4),
//                   ),
//                   children: [
//                     Padding(
//                       padding: const EdgeInsets.all(8.0),
//                       child: Center(
//                         child: Text(
//                           _selectedPlanet,
//                           style: TextStyle(
//                             fontWeight: FontWeight.bold,
//                             color: Colors.white,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//                 ...filteredDocs.map((doc) {
//                   final data = doc.data() as Map<String, dynamic>;
//                   final notes = data['notes']?.toString().trim() ?? 'குறிப்பு இல்லை';
//                   return TableRow(
//                     children: [
//                       Padding(
//                         padding: EdgeInsets.all(5),
//                         child: Text(
//                           notes,
//                           style: TextStyle(color: Colors.black),
//                         ),
//                       ),
//                     ],
//                   );
//                 }).toList(),
//               ],
//             ),
//           );
//         },
//       );
//     },
//   );
// }

// //star

// Widget _buildstarTable() {
//   return ValueListenableBuilder<String>(
//     valueListenable: _selectedStar,
//     builder: (context, _selectedStar, _) {
//       return StreamBuilder<QuerySnapshot>(
//         stream: FirebaseFirestore.instance
//             .collection('star')
//             .orderBy('timestamp')
//             .snapshots(),
//         builder: (context, snapshot) {
//           if (snapshot.hasError) {
//             return Center(child: Text('பிழை: ${snapshot.error}'));
//           }
//           if (!snapshot.hasData) {
//             return Center(child: CircularProgressIndicator());
//           }

//           final docs = snapshot.data!.docs;
//           final filteredDocs = docs.where((doc) {
//             final data = doc.data() as Map<String, dynamic>;
//             final rasi = data['rasi']?.toString().trim().toLowerCase();
//             return rasi == _selectedStar.trim().toLowerCase();
//           }).toList();

//           if (filteredDocs.isEmpty) {
//             return Center(
//               child: Text("தேர்ந்தெடுக்கப்பட்ட நட்சத்திரத்திற்கான குறிப்புகள் இல்லை."),
//             );
//           }

//           return SingleChildScrollView(
//             scrollDirection: Axis.vertical,
//             child: Table(
//               columnWidths: const {0: FlexColumnWidth()},
//               border: TableBorder.all(color: Color.fromARGB(255, 214, 130, 4)),
//               children: [
//                 TableRow(
//                   decoration: BoxDecoration(
//                     color: Color.fromARGB(255, 214, 130, 4),
//                   ),
//                   children: [
//                     Padding(
//                       padding: const EdgeInsets.all(8.0),
//                       child: Center(
//                         child: Text(
//                           _selectedStar,
//                           style: TextStyle(
//                             fontWeight: FontWeight.bold,
//                             color: Colors.white,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//                 ...filteredDocs.map((doc) {
//                   final data = doc.data() as Map<String, dynamic>;
//                   final notes = data['notes']?.toString().trim() ?? 'குறிப்பு இல்லை';
//                   return TableRow(
//                     children: [
//                       Padding(
//                         padding: EdgeInsets.all(5),
//                         child: Text(
//                           notes,
//                           style: TextStyle(color: Colors.black),
//                         ),
//                       ),
//                     ],
//                   );
//                 }).toList(),
//               ],
//             ),
//           );
//         },
//       );
//     },
//   );
// }


// ///rasi
// Widget _buildrasi() {
//   return ValueListenableBuilder<String>(
//     valueListenable: _selectedRasi,
//     builder: (context, _selectedRasi, _) {
//       return StreamBuilder<QuerySnapshot>(
//         stream: FirebaseFirestore.instance
//             .collection('service_notes')
//             .orderBy('timestamp')
//             .snapshots(),
//         builder: (context, snapshot) {
//           if (snapshot.hasError) {
//             return Center(child: Text('பிழை: ${snapshot.error}'));
//           }
//           if (!snapshot.hasData) {
//             return Center(child: CircularProgressIndicator());
//           }

//           final docs = snapshot.data!.docs;
//           final filteredDocs = docs.where((doc) {
//             final data = doc.data() as Map<String, dynamic>;
//             final rasi = data['rasi']?.toString().trim().toLowerCase();
//             return rasi == _selectedRasi.trim().toLowerCase();
//           }).toList();

//           if (filteredDocs.isEmpty) {
//             return Center(
//               child: Text("தேர்ந்தெடுக்கப்பட்ட நட்சத்திரத்திற்கான குறிப்புகள் இல்லை."),
//             );
//           }

//           return SingleChildScrollView(
//             scrollDirection: Axis.vertical,
//             child: Table(
//               columnWidths: const {0: FlexColumnWidth()},
//               border: TableBorder.all(color: Color.fromARGB(255, 214, 130, 4)),
//               children: [
//                 TableRow(
//                   decoration: BoxDecoration(
//                     color: Color.fromARGB(255, 214, 130, 4),
//                   ),
//                   children: [
//                     Padding(
//                       padding: const EdgeInsets.all(8.0),
//                       child: Center(
//                         child: Text(
//                           _selectedRasi,
//                           style: TextStyle(
//                             fontWeight: FontWeight.bold,
//                             color: Colors.white,
//                           ),
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//                 ...filteredDocs.map((doc) {
//                   final data = doc.data() as Map<String, dynamic>;
//                   final notes = data['notes']?.toString().trim() ?? 'குறிப்பு இல்லை';
//                   return TableRow(
//                     children: [
//                       Padding(
//                         padding: EdgeInsets.all(5),
//                         child: Text(
//                           notes,
//                           style: TextStyle(color: Colors.black),
//                         ),
//                       ),
//                     ],
//                   );
//                 }).toList(),
//               ],
//             ),
//           );
//         },
//       );
//     },
//   );
// }

// //two cmobination

// Widget _buildtwocombination() {
//   return StreamBuilder<QuerySnapshot>(
//     stream: FirebaseFirestore.instance
//         .collection('twocombination')
//         .orderBy('timestamp')
//         .snapshots(),
//     builder: (context, snapshot) {
//       if (snapshot.hasError) {
//         return Center(child: Text('பிழை: ${snapshot.error}'));
//       }
//       if (!snapshot.hasData) {
//         return Center(child: CircularProgressIndicator());
//       }

//       final docs = snapshot.data!.docs;

    

//       return ValueListenableBuilder<String>(
//         valueListenable: _twocombination,
//         builder: (context, selectedValue, _) {

//           // Filter notes based on selected value
//           final filteredDocs = docs.where((doc) {
//             final data = doc.data() as Map<String, dynamic>;
//             final rasi = data['two']?.toString().trim().toLowerCase();
//             return rasi == selectedValue.trim().toLowerCase();
//           }).toList();

//           return Column(
//             crossAxisAlignment: CrossAxisAlignment.stretch,
//             children: [
              
//               SizedBox(height: 10),
//               if (filteredDocs.isEmpty)
//                 Center(
//                   child: Text("தேர்ந்தெடுக்கப்பட்ட நட்சத்திரத்திற்கான குறிப்புகள் இல்லை."),
//                 )
//               else
//                 Expanded(
//                   child: SingleChildScrollView(
//                     scrollDirection: Axis.vertical,
//                     child: Table(
//                       columnWidths: const {0: FlexColumnWidth()},
//                       border: TableBorder.all(color: Color.fromARGB(255, 214, 130, 4)),
//                       children: [
//                         TableRow(
//                           decoration: BoxDecoration(
//                             color: Color.fromARGB(255, 214, 130, 4),
//                           ),
//                           children: [
//                             Padding(
//                               padding: const EdgeInsets.all(8.0),
//                               child: Center(
//                                 child: Text(
//                                   selectedValue,
//                                   style: TextStyle(
//                                     fontWeight: FontWeight.bold,
//                                     color: Colors.white,
//                                   ),
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                         ...filteredDocs.map((doc) {
//                           final data = doc.data() as Map<String, dynamic>;
//                           final notes = data['notes']?.toString().trim() ?? 'குறிப்பு இல்லை';
//                           return TableRow(
//                             children: [
//                               Padding(
//                                 padding: EdgeInsets.all(5),
//                                 child: Text(
//                                   notes,
//                                   style: TextStyle(color: Colors.black),
//                                 ),
//                               ),
//                             ],
//                           );
//                         }).toList(),
//                       ],
//                     ),
//                   ),
//                 ),
//             ],
//           );
//         },
//       );
//     },
//   );
// }

//   @override
//   void dispose() {
//     _selectedLagnam.dispose();
//     _selectedBhavam.dispose();
//     _selectedPlanet.dispose();
//     _selectedStar.dispose();
//     _selectedRasi.dispose();
    
//     super.dispose();
//   }

// //  @override
// // Widget build(BuildContext context) {
// //   return Scaffold(
// //     body: Padding(
// //       padding: const EdgeInsets.symmetric(vertical: 20),
// //       child: ListView(
// //         scrollDirection: Axis.horizontal,
// //         children: [
//   //         _buildDropdownWithTable(
//   //           title: "லக்கினம்",
//   //           options: lagnamList,
//   //           selected: _selectedLagnam,
//   //           color: Colors.deepPurple,
//   //           tableWidget: _buildLagnamTable(),
//   //           onChanged: (value) {
//   //
//   //               _selectedLagnam = value ?? _selectedLagnam;
//   //            
//   //           },
//   //         ),
//   //         _buildDropdownWithTable(
//   //           title: "பாவம்",
//   //           options: bhavamList,
//   //           selected: _selectedBhavam,
//   //           color: Colors.teal,
//   //           tableWidget: _buildBhavamTable(),
//   //           onChanged: (value) {
//   //             
//   //               _selectedBhavam = value ?? _selectedBhavam;
//   //            
//   //           },
//   //         ),
//   //         _buildDropdownWithTable(
//   //           title: "கிரஹம்",
//   //           options: planetList,
//   //           selected: _selectedPlanet,
//   //           color: Colors.orange,
//   //           tableWidget: _buildPlanetTable(),
//   //           onChanged: (value) {
//   //
//   //               _selectedPlanet = value ?? _selectedPlanet;
//   //             
//   //           },
//   //         ),
//   //         _buildDropdownWithTable(
//   //           title: "நட்சத்திரம்",
//   //           options: starList,
//   //           selected: _selectedStar,
//   //           color: Colors.indigo,
//   //           tableWidget: _buildStarTable(),
//   //           onChanged: (value) {
//   //           
//   //               _selectedStar = value ?? _selectedStar;
//   //            
//   //           },
//   //         ),
//   //         _buildDropdownWithTable(
//   //           title: "ராசி",
//   //           options: rasiList,
//   //           selected: _selectedRasi,
//   //           color: Colors.green,
//   //           tableWidget: _buildRasiTable(),
//   //           onChanged: (value) {
//   //           
//   //        
//   //           },
//   //         ),
//   //         _buildDropdownWithTable(
//   //           title: "2 கிரஹம் சேர்க்கை",
//   //           options: twoPlanetCombinations,
//   //           selected: _twoCombination,
//   //           color: Colors.green,
//   //           tableWidget: _buildTwoCombinationTable(),
//   //           onChanged: (value) {
//   //             
//   //               _twoCombination = value ?? _twoCombination;
//   //            
//   //           },
//   //         ),
//   //       ],
//   //     ),
//   //   ),
//   // );
// //}

// // Widget _buildDropdownWithTable({
// //   required String title,
// //   required List<String> options,
// //   required String selected,
// //   required Color color,
// //   required Widget tableWidget,
// //   required Function onChanged,
// // }) {
// //   return Container(
// //     margin: const EdgeInsets.all(10),
// //     child: Column(
// //       children: [
// //         Text(
// //           title,
// //           style: TextStyle(
// //             fontSize: 18,
// //             fontWeight: FontWeight.bold,
// //             color: color,
// //           ),
// //         ),
// //         DropdownButtonFormField(
// //           decoration: InputDecoration(
// //             border: OutlineInputBorder(
// //               borderRadius: BorderRadius.circular(10),
// //             ),
// //           ),
// //           value: selected,
// //           onChanged: (value) => onChanged(value),
// //           items: options.map((option) {
// //             return DropdownMenuItem(
// //               child: Text(option),
// //               value: option,
// //             );
// //           }).toList(),
// //         ),
// //         tableWidget,
// //       ],
// //     ),
// //   );
// // }
// // }
// }