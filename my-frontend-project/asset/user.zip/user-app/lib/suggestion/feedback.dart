import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:usertest/register/register.dart';
import 'package:usertest/widgets/inputfield.dart';

class suggestion extends StatefulWidget {
  const suggestion({super.key});

  @override
  State<suggestion> createState() => _suggestionScreenState();
}

class _suggestionScreenState extends State<suggestion> {
  
  final suggestion = TextEditingController();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  void _submitSuggestion() async {
 
    String idea = suggestion.text.trim();

    if (idea.isEmpty) {
      _showMessage("Please fill both fields.");
      return;
    }

    try {
      await _firestore.collection('suggestion').add({
        
        'suggestion': idea,
        'timestamp': FieldValue.serverTimestamp(), // optional
      });

      _showMessage("Suggestion submitted!");
     
      suggestion.clear();
    } catch (e) {
      _showMessage("Error: $e");
    }
  }

  void _showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            double screenWidth = constraints.maxWidth;
            double padding = screenWidth > 600 ? 40 : 20;

            return Padding(
              padding: EdgeInsets.all(padding),
              child: ListView(
                children: [
                  const SizedBox(height: 30),
                  const Text(
                    "User Suggestion",
                    style: TextStyle(
                      fontSize: 24,
                      color: Color.fromARGB(255, 168, 50, 227),
                    ),
                  ),
                  const SizedBox(height: 20),
                 
                  CustomTextField(
                    label: "Your Suggestion",
                    icon: Icons.message,
                    controller: suggestion,
                      textInputAction: TextInputAction.next,

                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _submitSuggestion,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepPurple,
                    ),
                    child: const Text(
                      "Submit",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  const SizedBox(height: 20),
                  GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => RegisterScreen()),
                    ),
                    child: const Text(
                      "Go to Registration",
                      style: TextStyle(color: Colors.blue),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
