import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/dashboard/dashboard.dart';
import 'package:usertest/allbuttons/common_notes_table.dart';
import 'package:usertest/allbuttons/dropdown.dart';
import 'package:usertest/widgets/CustomGradientAppBar.dart';

class RasiDisplay extends StatefulWidget {
  const RasiDisplay({Key? key}) : super(key: key);

  @override
  _RasiDisplayState createState() => _RasiDisplayState();
}

class _RasiDisplayState extends State<RasiDisplay> {
  final ValueNotifier<String?> _selectedRasi = ValueNotifier<String?>('மேஷம்');
  final ValueNotifier<String?> _selectedZoomLevel = ValueNotifier<String?>('1');

  final List<String> _rasiList = [
    'மேஷம்',
    'ரிஷபம்',
    'மிதுனம்',
    'கடகம்',
    'சிம்மம்',
    'கன்னி',
    'துலாம்',
    'விருச்சிகம்',
    'தனுசு',
    'மகரம்',
    'கும்பம்',
    'மீனம்',
  ];

  Stream<QuerySnapshot> _getRasiStream() {
    return FirebaseFirestore.instance
        .collection('service_notes')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  void dispose() {
    _selectedRasi.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    final horizontalPadding =
        screenWidth > 600 ? screenWidth * 0.1 : screenWidth * 0.04;
    final topSpacing = screenHeight * 0.04;
    return Scaffold(
      appBar: CustomGradientAppBar(
        title: "ராசி குறிப்புகள்",
        onBack:
            () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const HomePage()),
            ),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return Container(
              color: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
              child: Column(
                children: [
                  SizedBox(height: topSpacing + 20),
                  _buildDropdownWithCountBadge(screenWidth, screenHeight),
                  SizedBox(height: screenHeight * 0),
                  Expanded(child: _buildNotesTable()),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildDropdownWithCountBadge(double screenWidth, double screenHeight) {
    return ValueListenableBuilder<String?>(
      valueListenable: _selectedRasi,
      builder: (context, selectedRasi, _) {
        return StreamBuilder<QuerySnapshot>(
          stream: _getRasiStream(),
          builder: (context, snapshot) {
            int count = 0;
            if (snapshot.hasData && selectedRasi != null) {
              count =
                  snapshot.data!.docs
                      .where(
                        (doc) =>
                            (doc.data() as Map<String, dynamic>)['rasi'] ==
                            selectedRasi,
                      )
                      .length;
            }

            return Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(left: screenWidth * 0.04),
                    child: StyledDropdown(
                      selectedValue: _selectedRasi,
                      items: _rasiList,
                      hintText: "ராசியை தேர்வு செய்க",
                    ),
                  ),
                ),
                SizedBox(width: screenWidth * 0.05),
                _buildCountBadge(count, screenHeight, screenWidth),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildCountBadge(int count, double screenHeight, double screenWidth) {
    return Transform.translate(
      offset: Offset(0, -screenHeight * 0.03),
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.04,
          vertical: screenHeight * 0.01,
        ),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF3E0),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.orange.withOpacity(0.3),
              blurRadius: 6,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(
              Icons.list_alt_rounded,
              color: Color(0xFFE65100),
              size: 20,
            ),
            SizedBox(width: screenWidth * 0.015),
            Text(
              "$count",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: screenWidth * 0.045,
                color: const Color(0xFFBF360C),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNotesTable() {
    return ValueListenableBuilder<String?>(
      valueListenable: _selectedRasi,
      builder: (context, selectedRasi, _) {
        if (selectedRasi == null) {
          return const Center(
            child: Text(
              "முதலில் ஒரு ராசியைத் தேர்ந்தெடுக்கவும்.",
              style: TextStyle(fontSize: 16),
            ),
          );
        }

        return StreamBuilder<QuerySnapshot>(
          stream: _getRasiStream(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(child: Text('பிழை: ${snapshot.error}'));
            }
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }

            final filteredDocs =
                snapshot.data!.docs.where((doc) {
                  return (doc.data() as Map<String, dynamic>)['rasi'] ==
                      selectedRasi;
                }).toList();

            if (filteredDocs.isEmpty) {
              return const Center(
                child: Text("தேர்ந்தெடுக்கப்பட்ட ராசிக்கான குறிப்புகள் இல்லை."),
              );
            }

            return CommonNotesTable(
              docs: filteredDocs,
              selectedValue: selectedRasi,
              filterKey: 'rasi',
              defaultLabel: "ராசி",
            );
          },
        );
      },
    );
  }
}
