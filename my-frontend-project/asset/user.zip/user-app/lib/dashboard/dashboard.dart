import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:usertest/allbuttons/combined_combinations.dart';
import 'package:usertest/allbuttons/starbutton.dart';
import 'package:usertest/combination.dart';
import 'package:usertest/datadisplay/advertisement.dart';
import 'package:usertest/datadisplay/ai.dart';
import 'package:usertest/datadisplay/bhavam.dart';
import 'package:usertest/datadisplay/combined_combination_display_alt.dart';
import 'package:usertest/datadisplay/dhosham.dart';
import 'package:usertest/datadisplay/lagnam.dart';
import 'package:usertest/datadisplay/malar.dart';
import 'package:usertest/datadisplay/mantrigam.dart';
import 'package:usertest/datadisplay/pariharam.dart';
import 'package:usertest/datadisplay/parvai.dart';
import 'package:usertest/datadisplay/planet.dart';
import 'package:usertest/datadisplay/prasanam.dart';
import 'package:usertest/datadisplay/prediction.dart';
import 'package:usertest/datadisplay/star.dart';
import 'package:usertest/datadisplay/thantrigam.dart';
import 'package:usertest/datadisplay/threecombination.dart';
import 'package:usertest/datadisplay/twocombination.dart';
import 'package:usertest/login/login.dart';
import 'package:usertest/rasi.dart';
import 'package:usertest/research/research_screen.dart';
import 'package:usertest/rowdisp.dart';
import 'package:usertest/sidrbar.dart';
import 'package:usertest/suggestion/feedback.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _searchQuery = '';
  final ValueNotifier<String?> _selectedCombined = ValueNotifier(null);

  Future<String?> fetchUsername() async {
    try {
      final userId = FirebaseAuth.instance.currentUser?.uid;
      if (userId != null) {
        final doc =
            await FirebaseFirestore.instance
                .collection('users')
                .doc(userId)
                .get();
        return doc.data()?['username'] ?? 'No Name';
      } else {
        return 'Guest';
      }
    } catch (e) {
      return 'Error';
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    int crossAxisCount = (screenWidth / 160).floor().clamp(2, 4);

    final List<Map<String, dynamic>> _allButtons = [
      {
        'title': 'அனைத்தும்',
        'color': Colors.white,
        'image': 'assets/all.png',
        'widget': CombinedDisplayScreen(),
      },
      {
        'title': 'லக்னம்',
        'color': Colors.white,
        'image': 'assets/lagnam.png',
        'widget': LagnamDisplay(),
      },
      {
        'title': 'பாவம்',
        'color': Colors.white,
        'image': 'assets/bhavam.png',
        'widget': Bhavam(),
      },
      {
        'title': 'கிரகம்',
        'color': Colors.white,
        'image': 'assets/kiragam.png',
        'widget': PlanetDisplay(),
      },
      {
        'title': 'நட்சத்திரம்',
        'color': Colors.white,
        'image': 'assets/st.png',
        'widget': Stardisplay(),
      },
      {
        'title': 'ராசி',
        'color': Colors.white,
        'image': 'assets/ra.png',
        'widget': RasiDisplay(),
      },
      {
        'title': 'கிரக சேர்க்கை',
        'color': Colors.white,
        'image': 'assets/three.png',
        'widget': CombinedCombinationDisplayAlt(notifier: _selectedCombined),
      },

      {
        'title': 'ஏ.ஐ',
        'color': Colors.white,
        'image': 'assets/ai.png',
        'widget': AIdata(),
      },
      {
        'title': 'தோஷம்',
        'color': Colors.white,
        'image': 'assets/dhosham.png',
        'widget': Dhosham(),
      },
      {
        'title': 'மலர் மருத்துவம்',
        'color': Colors.white,
        'image': 'assets/malar.png',
        'widget': Malar(),
      },
      {
        'title': 'மந்திரிகம்',
        'color': Colors.white,
        'image': 'assets/mantrigam.png',
        'widget': Mantrigam(),
      },
      {
        'title': 'கிரக பார்வை',
        'color': Colors.white,
        'image': 'assets/planetparvai.png',
        'widget': Parvai(),
      },
      {
        'title': 'பிரசன்னம்',
        'color': Colors.white,
        'image': 'assets/prasanam.png',
        'widget': Prasanam(),
      },
      {
        'title': 'பரிகாரம்',
        'color': Colors.white,
        'image': 'assets/pariharam.png',
        'widget': Pariharam(),
      },
      {
        'title': 'தாந்திரிகம்',
        'color': Colors.white,
        'image': 'assets/thantrigam.png',
        'widget': Thantrigam(),
      },
      {
        'title': 'ஆராய்ச்சி', // Research in Tamil
        'color': Colors.white,
        'image': 'assets/thantrigam.png',
        'widget': ResearchScreen(), // This is the screen you’ll create below
      },

    ];

    return Scaffold(
      backgroundColor: Colors.white,
      drawer: const Drawer(child: Sidebar()),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(60),
        child: ClipRRect(
          child: AppBar(
            elevation: 6,
            backgroundColor: Colors.transparent,
            flexibleSpace: Stack(
              children: [
                Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Color.fromARGB(255, 255, 140, 90),
                        Color.fromARGB(255, 244, 103, 60),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.05), // glossy overlay
                  ),
                ),
              ],
            ),
            toolbarHeight: 60,
            iconTheme: const IconThemeData(color: Colors.white),
            title: const Text(
              'RK Astro',
              style: TextStyle(
                fontSize: 22,
                letterSpacing: 1.2,
                fontWeight: FontWeight.bold,
                color: Colors.white,
                shadows: [
                  Shadow(
                    color: Colors.black38,
                    offset: Offset(0, 1),
                    blurRadius: 2,
                  ),
                ],
              ),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.search, color: Colors.white),
                onPressed: () {
                  showSearch(
                    context: context,
                    delegate: AstroSearchDelegate(_allButtons),
                  );
                },
              ),
            ],
          ),
        ),
      ),

      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            double screenWidth = constraints.maxWidth;
            int crossAxisCount = (screenWidth / 120).floor();
            crossAxisCount = crossAxisCount.clamp(2, 5);

            return SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Column(
                children: [
                  HorizontalAdsScreen(),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          // Horoscope logic here
                          showWorkInProgressDialog(context);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange,
                        ),
                        child: const Text(
                          'Horoscope',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 30),
                  GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: crossAxisCount,
                      crossAxisSpacing: 20,
                      mainAxisSpacing: 20,
                    ),
                    itemCount: _allButtons.length,
                    itemBuilder: (context, index) {
                      final item = _allButtons[index];
                      return buildButton(
                        color: item['color'] as Color,
                        imageUrl: item['image'] as String,
                        title: item['title'] as String,
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => item['widget'] as Widget,
                            ),
                          );
                        },
                      );
                    },
                  ),
                ],
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.deepPurple,
        child: const Icon(Icons.smart_toy, color: Colors.white),
        onPressed: () {
          // Navigator.push(
          //   context,
          //   MaterialPageRoute(builder: (context) => const AiAssistantScreen()),
          // );
        },
      ),
    );
  }

  Widget buildButton({
    required Color color,
    required String imageUrl,
    required String title,
    required VoidCallback onTap,
  }) {
    return LayoutBuilder(
      builder: (context, constraints) {
        double fontSize = constraints.maxWidth < 100 ? 8 : 10;

        return GestureDetector(
          onTap: onTap,
          child: Container(
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.orange.withOpacity(0.5),
                  blurRadius: 10,
                  spreadRadius: 3,
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(radius: 35, backgroundImage: AssetImage(imageUrl)),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 0,
                    vertical: 0,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white70,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    title,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: fontSize,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

Future<void> showWorkInProgressDialog(BuildContext context) {
  return showDialog(
    context: context,
    builder: (BuildContext dialogContext) {
      return AlertDialog(
        title: const Text('Notice'),
        content: const Text('Work in progress'),
        actions: <Widget>[
          TextButton(
            child: const Text('OK'),
            onPressed: () {
              Navigator.pop(dialogContext); // Close the dialog
            },
          ),
        ],
      );
    },
  );
}

class AstroSearchDelegate extends SearchDelegate {
  final List<Map<String, dynamic>> buttons;
  final stt.SpeechToText _speech = stt.SpeechToText();
  final ValueNotifier<bool> _isListening = ValueNotifier(false);

  AstroSearchDelegate(this.buttons);

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      if (query.isNotEmpty)
        IconButton(
          icon: const Icon(Icons.clear),
          onPressed: () {
            query = '';
            showSuggestions(context);
          },
        ),
      ValueListenableBuilder<bool>(
        valueListenable: _isListening,
        builder: (context, isListening, _) {
          return IconButton(
            icon: Icon(
              isListening ? Icons.mic : Icons.mic_none,
              color: isListening ? Colors.red : null,
            ),
            onPressed: () async {
              if (!isListening) {
                bool available = await _speech.initialize(
                  onStatus: (status) {
                    if (status == 'done' || status == 'notListening') {
                      _stopListening(context);
                    }
                  },
                  onError: (error) {
                    print('Speech error: $error');
                    _stopListening(context);
                  },
                );

                if (available) {
                  _speech.listen(
                    onResult: (result) {
                      query = result.recognizedWords;
                      showResults(context);
                    },
                  );
                  _isListening.value = true;
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Voice input not available')),
                  );
                }
              } else {
                _stopListening(context);
              }
            },
          );
        },
      ),
    ];
  }

  void _stopListening(BuildContext context) {
    _speech.stop();
    _isListening.value = false;
    showSuggestions(context);
  }

  @override
  void close(BuildContext context, result) {
    _speech.stop();
    _isListening.value = false;
    super.close(context, result);
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () => close(context, null),
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    final lowerQuery = query.toLowerCase();

    final results =
        buttons.where((item) {
          final title = (item['title'] as String).toLowerCase();
          final keywords = (item['keywords'] ?? []) as List<dynamic>;
          final keywordMatch = keywords.any(
            (k) => (k as String).toLowerCase().contains(lowerQuery),
          );

          return title.contains(lowerQuery) || keywordMatch;
        }).toList();

    return results.isEmpty
        ? Center(
          child: Text(
            'தேடலில் பொருத்தமான பெறுமானம் இல்லை',
            style: TextStyle(fontSize: 16, color: Colors.grey[600]),
          ),
        )
        : GridView.builder(
          padding: const EdgeInsets.all(16),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
          ),
          itemCount: results.length,
          itemBuilder: (context, index) {
            final item = results[index];
            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => item['widget'] as Widget,
                  ),
                );
              },
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      item['color'].withOpacity(0.9),
                      item['color'].withOpacity(0.7),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: const [
                    BoxShadow(
                      color: Colors.black26,
                      blurRadius: 6,
                      offset: Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundImage: AssetImage(item['image']),
                      backgroundColor: Colors.white,
                    ),
                    const SizedBox(height: 12),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        item['title'],
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return buildResults(context);
  }
}
