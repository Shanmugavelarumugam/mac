

import 'package:cloud_firestore/cloud_firestore.dart';

class function {
Future<void>  bhavamdata() async{
 Stream<QuerySnapshot> _getStarStream() {
    return FirebaseFirestore.instance
        .collection('bhavam')
        .orderBy('timestamp')
        .snapshots();
  }

}

}
