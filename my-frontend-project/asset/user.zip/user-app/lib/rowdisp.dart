import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'package:usertest/allbuttons/bhavambutton.dart';
import 'package:usertest/allbuttons/combined_combinations.dart';
import 'package:usertest/allbuttons/lagnambutton.dart';
import 'package:usertest/allbuttons/planet.dart';
import 'package:usertest/allbuttons/rasibutton.dart';
import 'package:usertest/allbuttons/starbutton.dart';
import 'package:usertest/dashboard/dashboard.dart';

class CombinedDisplayScreen extends StatefulWidget {
  final String? initialLagnam;
  final String? initialBhavam;
  final String? initialPlanet;
  final String? initialStar;
  final String? initialRasi;
  final String? initialCombine;

  const CombinedDisplayScreen({
    super.key,
    this.initialLagnam,
    this.initialBhavam,
    this.initialPlanet,
    this.initialStar,
    this.initialRasi,
    this.initialCombine,
  });

  @override
  State<CombinedDisplayScreen> createState() => _CombinedDisplayScreenState();
}

class _CombinedDisplayScreenState extends State<CombinedDisplayScreen> {
  final ValueNotifier<String?> _selectedLagnam = ValueNotifier(null);
  final ValueNotifier<String?> _selectedBhavam = ValueNotifier(null);
  final ValueNotifier<String?> _selectedPlanet = ValueNotifier(null);
  final ValueNotifier<String?> _selectedStar = ValueNotifier(null);
  final ValueNotifier<String?> _selectedRasi = ValueNotifier(null);
  final ValueNotifier<String?> _selectedCombined = ValueNotifier(null);

  final ValueNotifier<String?> _filterNotifier = ValueNotifier('All');
  final ValueNotifier<double> _zoomLevel = ValueNotifier(1.0);

  final List<String> filterOptions = [
    'All',
    'Positive',
    'Negative',
    'Strong',
    'Weak',
  ];

  void _zoomIn() {
    _zoomLevel.value += 0.1;
  }

  void _zoomOut() {
    _zoomLevel.value -= 0.03;
    if (_zoomLevel.value < 0.7) {
      _zoomLevel.value = 0.7; // optional limit
    }
  }

  @override
  void initState() {
    super.initState();
    _selectedLagnam.value = widget.initialLagnam ?? "மேஷம் லக்னம்";
    _selectedBhavam.value = widget.initialBhavam ?? "முதல் பாவம்";
    _selectedPlanet.value = widget.initialPlanet ?? 'சூரியன்';
    _selectedStar.value = widget.initialStar;
    _selectedRasi.value = widget.initialRasi ?? "மேஷம்";
    _selectedCombined.value = widget.initialCombine ?? "சூரி+ சந்";

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    super.dispose();
  }



  Future<void> _bookmarkCombination() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    String? bookmarkName = await showDialog<String>(
      context: context,
      builder: (context) {
        String tempName = '';
        return AlertDialog(
          title: const Text("Give a name to your bookmark"),
          content: TextField(
            decoration: const InputDecoration(hintText: "e.g., Hari"),
            onChanged: (value) => tempName = value,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, tempName),
              child: const Text("Save"),
            ),
          ],
        );
      },
    );

    if (bookmarkName == null || bookmarkName.trim().isEmpty) return;

    final data = {
      'uid': user.uid,
      'bookmarkName': bookmarkName.trim(),
      'lagnam': _selectedLagnam.value ?? '',
      'bhavam': _selectedBhavam.value ?? '',
      'planet': _selectedPlanet.value ?? '',
      'star': _selectedStar.value ?? '',
      'rasi': _selectedRasi.value ?? '',
      'combined': _selectedCombined.value ?? '',
      'timestamp': FieldValue.serverTimestamp(),
    };

    await FirebaseFirestore.instance.collection('bookmarks').add(data);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Bookmark saved successfully!')),
    );
  }

  Widget _buildFilterDropdown() {
    return ValueListenableBuilder2<String?, double>(
      first: _filterNotifier,
      second: _zoomLevel,
      builder: (context, value, zoom, _) {
        return Transform.translate(
          offset: const Offset(0, -2),
          child: Container(
            margin: const EdgeInsets.only(left: 10),
            padding: const EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.deepOrange, width: 0.8),
              borderRadius: BorderRadius.circular(5),
            ),
            child: SizedBox(
              height: 32,
              width: 70,
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  isExpanded: true,
                  value: value,
                  icon: Icon(
                    Icons.arrow_drop_down,
                    size: 18 * zoom,
                    color: Color(0xFFFF7043)
                  ),
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    color: Color(0xFFFF7043),
                    fontSize: 12 * zoom,
                  ),
                  items:
                      filterOptions
                          .map(
                            (String option) => DropdownMenuItem<String>(
                              value: option,
                              child: Text(
                                option,
                                style: TextStyle(fontSize: 12 * zoom, color: Color(0xFFFF7043)),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          )
                          .toList(),
                  onChanged: (newValue) {
                    _filterNotifier.value = newValue;
                  },
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildZoomControls() {
    return ValueListenableBuilder<double>(
      valueListenable: _zoomLevel,
      builder: (context, zoom, _) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.deepOrange, width: 0.8),
            borderRadius: BorderRadius.circular(5),
          ),
          child: SizedBox(
            height: 35,
            width: 135,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  icon: const Icon(Icons.remove, size: 18, color: Color(0xFFFF7043),),
                  onPressed: _zoomOut
                ),
                Text(
                  "${(zoom * 100).round()}%",
                  style: const TextStyle(fontSize: 13,color: Color(0xFFFF7043)),
                ),
                IconButton(
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  icon: const Icon(Icons.add, size: 18, color: Color(0xFFFF7043),),
                  onPressed: _zoomIn
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _resetButton() {
    return ValueListenableBuilder<double>(
      valueListenable: _zoomLevel,
      builder: (context, zoom, _) {
        return Container(
          //margin: const EdgeInsets.only(right: 10),
          padding: const EdgeInsets.symmetric(horizontal: 4),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.deepOrange, width: 0.8),
            borderRadius: BorderRadius.circular(5),
          ),
          child: SizedBox(
            height: 35,
            width: 60,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  icon: const Icon(Icons.refresh, color: Color(0xFFFF7043),),
                  onPressed: () {
                    _zoomLevel.value = 1.0;
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final isLandscape =
        MediaQuery.of(context).orientation == Orientation.landscape;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(
                      Icons.arrow_back_ios_new,
                      color:Color(0xFFFF7043),
                      size: isLandscape ? 18 : 22,
                    ),
                  ),
                  // IconButton(
                  //   padding: EdgeInsets.zero,
                  //   icon: Icon(Icons.arrow_back_ios_new,
                  //       color: Colors.black, size: isLandscape ? 18 : 22),
                  //   onPressed: () {
                  //    Navigator.pop(context);
                  //   },
                  // ),
                  _buildFilterDropdown(),
                  Spacer(),
                  Text(
                    "அனைத்தும்",
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: Color(0xFFFF7043)
                    ),
                  ),
                  Spacer(),
                  _buildZoomControls(),
                  SizedBox(width: 5),
                  _resetButton(),
                ],
              ),
            ),
      Expanded(
        child: ValueListenableBuilder<double>(
          valueListenable: _zoomLevel,
          builder: (context, zoom, _) {
            return LayoutBuilder(
              builder: (context, constraints) {
                double baseWidth = constraints.maxWidth;

                return SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: (zoom >= 1.0)
                  // ------------------------
                  // ZOOM IN (same as before)
                  // ------------------------
                      ? Transform.scale(
                    scale: zoom,
                    alignment: Alignment.topLeft,
                    child: Row(
                      children: [
                        SizedBox(
                          width: baseWidth / 6,
                          child: Lagnam(
                            notifier: _selectedLagnam,
                            selectedLagnamNotifier: _selectedLagnam,
                            zoom: zoom,
                          ),
                        ),
                        SizedBox(
                          width: baseWidth / 6,
                          child: Bhavam(notifier: _selectedBhavam,zoom: zoom,),
                        ),
                        SizedBox(
                          width: baseWidth / 6,
                          child: PlanetDisplay(notifier: _selectedPlanet,zoom: zoom,),
                        ),
                        SizedBox(
                          width: baseWidth / 6,
                          child: Starsdisplay(notifier: _selectedStar, zoom: zoom,),
                        ),
                        SizedBox(
                          width: baseWidth / 6,
                          child: RasiDisplay(notifier: _selectedRasi,zoom: zoom,),
                        ),
                        SizedBox(
                          width: baseWidth / 6,
                          child: CombinedCombinationDisplay(
                            zoom: zoom,
                              notifier: _selectedCombined),
                        ),
                      ],
                    ),
                  )
                  // ------------------------
                  // ZOOM OUT (static table, scrollable row)
                  // ------------------------
                      : SizedBox(
                    width: baseWidth, // keep row width fixed
                    child: Row(
                      children: [
                        SizedBox(
                          width: baseWidth / 6,
                          child: Transform.scale(
                            scale: zoom,
                            alignment: Alignment.topCenter,
                            child: Lagnam(
                              notifier: _selectedLagnam,
                              selectedLagnamNotifier: _selectedLagnam,
                              zoom: zoom,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: baseWidth / 6,
                          child: Transform.scale(
                            scale: zoom,
                            alignment: Alignment.topCenter,
                            child: Bhavam(notifier: _selectedBhavam,zoom: zoom,),
                          ),
                        ),
                        SizedBox(
                          width: baseWidth / 6,
                          child: Transform.scale(
                            scale: zoom,
                            alignment: Alignment.topCenter,
                            child: PlanetDisplay(notifier: _selectedPlanet, zoom: zoom,),
                          ),
                        ),
                        SizedBox(
                          width: baseWidth / 6,
                          child: Transform.scale(
                            scale: zoom,
                            alignment: Alignment.topCenter,
                            child: Starsdisplay(notifier: _selectedStar, zoom: zoom,),
                          ),
                        ),
                        SizedBox(
                          width: baseWidth / 6,
                          child: Transform.scale(
                            scale: zoom,
                            alignment: Alignment.topCenter,
                            child: RasiDisplay(notifier: _selectedRasi,zoom: zoom,),
                          ),
                        ),
                        SizedBox(
                          width: baseWidth / 6,
                          child: Transform.scale(
                            scale: zoom,
                            alignment: Alignment.topCenter,
                            child: CombinedCombinationDisplay(
                              zoom: zoom,
                                notifier: _selectedCombined),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      )
      ],
        ),
      ),
    );
  }

  Widget _buildDetailField(String hint) {
    return TextField(
      decoration: InputDecoration(
        hintText: hint,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      ),
    );
  }
}

class ValueListenableBuilder2<A, B> extends StatelessWidget {
  final ValueListenable<A> first;
  final ValueListenable<B> second;
  final Widget Function(BuildContext, A, B, Widget?) builder;
  final Widget? child;

  const ValueListenableBuilder2({
    super.key,
    required this.first,
    required this.second,
    required this.builder,
    this.child,
  });

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<A>(
      valueListenable: first,
      builder: (context, valueA, _) {
        return ValueListenableBuilder<B>(
          valueListenable: second,
          builder: (context, valueB, __) {
            return builder(context, valueA, valueB, child);
          },
        );
      },
    );
  }
}
