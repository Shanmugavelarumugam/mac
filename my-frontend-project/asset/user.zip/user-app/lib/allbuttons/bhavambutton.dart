import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/allbuttons/common_notes_table.dart';
import 'package:usertest/allbuttons/dropdown.dart';

class Bhavam extends StatefulWidget {
  final ValueNotifier<String?> notifier;
  final double zoom;// ✅ Accept external notifier

  const Bhavam({super.key, required this.notifier, required this.zoom});

  @override
  State<Bhavam> createState() => _BhavamDisplayState();
}

class _BhavamDisplayState extends State<Bhavam> {
  final List<String> bhavalist = [
    "முதல் பாவம்",
    'இரண்டாம் பாவம்',
    'மூன்றாம் பாவம்',
    'நான்காம் பாவம்',
    'ஐந்தாம் பாவம்',
    'ஆறாம் பாவம்',
    'ஏழாம் பாவம்',
    'எட்டாம் பாவம்',
    'ஒன்பதாம் பாவம்',
    'பத்தாம் பாவம்',
    'பதினொன்றாம் பாவம்',
    'பன்னிரண்டாம் பாவம்',
  ];

  Stream<QuerySnapshot> _getBhavamStream() {
    return FirebaseFirestore.instance
        .collection('bhavam')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        color: Colors.white,
        width: MediaQuery.sizeOf(context).width,
        child: Column(
          children: [
            const SizedBox(height: 10),
            _buildFilterDropdown(),
            Expanded(child: _buildTable()),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterDropdown() {
    return Padding(
      padding: const EdgeInsets.only(right: 4),
      child: StyledDropdown(
        selectedValue: widget.notifier,
        items: const [
          "முதல் பாவம்",
          "இரண்டாம் பாவம்",
          "மூன்றாம் பாவம்",
          "நான்காம் பாவம்",
          "ஐந்தாம் பாவம்",
          "ஆறாம் பாவம்",
          "ஏழாம் பாவம்",
          "எட்டாம் பாவம்",
          "ஒன்பதாம் பாவம்",
          "பத்தாம் பாவம்",
          "பதினொன்றாம் பாவம்",
          "பன்னிரண்டாம் பாவம்",
        ],
        hintText: "பாவம் மூலம் வடிகட்டி",
      ),
    );
  }

  Widget _buildTable() {
    return StreamBuilder<QuerySnapshot>(
      stream: _getBhavamStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('பிழை: ${snapshot.error}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        return ValueListenableBuilder<String?>(
          valueListenable: widget.notifier,
          builder: (context, selectedStar, _) {
            return CommonNotesTable(
              docs: docs,
              selectedValue: selectedStar,
              filterKey: "bhavam",
              defaultLabel: "முதல் பாவம்",
              zoom: widget.zoom,
            );
          },
        );
      },
    );
  }
}
