import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/allbuttons/common_notes_table.dart';
import 'package:usertest/allbuttons/dropdown.dart';

class Lagnam extends StatefulWidget {
  final ValueNotifier<String?> selectedLagnamNotifier;
  final double zoom;//
  const Lagnam({
    super.key,
    required this.selectedLagnamNotifier,
    required ValueNotifier<String?> notifier,
    required this.zoom
  });

  @override
  _LagnamState createState() => _LagnamState();
}

class _LagnamState extends State<Lagnam> {
  final List<String> _lagnamList = [
    'ரிஷபம் லக்னம்',
    'மிதுனம் லக்னம்',
    'கடகம் லக்னம்',
    'சிம்மம் லக்னம்',
    'கன்னி லக்னம்',
    'துலாம் லக்னம்',
    'விருச்சிகம் லக்னம்',
    'தனுசு லக்னம்',
    'மகரம் லக்னம்',
    'கும்பம் லக்னம்',
    'மீனம் லக்னம்',
  ];

  Stream<QuerySnapshot> _getLagnamStream() {
    return FirebaseFirestore.instance
        .collection('lagnam')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      width: MediaQuery.sizeOf(context).width,
      child: Column(
        children: [
          const SizedBox(height: 10),
          _buildFilterDropdown(),
          Expanded(child: _buildTable()),
        ],
      ),
    );
  }

  Widget _buildFilterDropdown() {
    final List<String> fullList = ['மேஷம் லக்னம்', ..._lagnamList];
    return Padding(
      padding: const EdgeInsets.only(right: 4),
      child: StyledDropdown(
        selectedValue: widget.selectedLagnamNotifier,
        items: fullList,
        hintText: "லக்னம் மூலம் வடிகட்டி",
      ),
    );
  }

  Widget _buildTable() {
    return StreamBuilder<QuerySnapshot>(
      stream: _getLagnamStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('பிழை: ${snapshot.error}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        return ValueListenableBuilder<String?>(
          valueListenable: widget.selectedLagnamNotifier,
          builder: (context, selectedLagnam, _) {
            return CommonNotesTable(
              docs: docs,
              selectedValue: selectedLagnam,
              filterKey: "lagnam",
              defaultLabel: "மேஷம் லக்னம்",
              zoom: widget.zoom,
            );
          },
        );
      },
    );
  }
}
