import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/allbuttons/common_notes_table.dart';
import 'package:usertest/allbuttons/dropdown.dart';

class PlanetDisplay extends StatefulWidget {
  final ValueNotifier<String?>? notifier;
  final double zoom;//// Optional external notifier

  const PlanetDisplay({Key? key, this.notifier, required this.zoom}) : super(key: key);

  @override
  _PlanetDisplayState createState() => _PlanetDisplayState();
}

class _PlanetDisplayState extends State<PlanetDisplay> {
  late final ValueNotifier<String?> _selectedPlanet;

  final List<String> _planetList = [
    'சூரியன்',
    'சந்திரன்',
    'செவ்வாய்',
    'புதன்',
    'குரு',
    'சுக்கிரன்',
    'சனி',
    'ராகு',
    'கேது',
  ];

  Stream<QuerySnapshot> _getPlanetStream() {
    return FirebaseFirestore.instance
        .collection('planet')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  void initState() {
    super.initState();
    _selectedPlanet = widget.notifier ?? ValueNotifier('சூரியன்');
  }

  @override
  void dispose() {
    if (widget.notifier == null) {
      _selectedPlanet.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        color: Colors.white,
        width: MediaQuery.sizeOf(context).width,
        child: Column(
          children: [
             const SizedBox(height: 10),
             _buildFilterDropdown(),
            Expanded(child: _buildTable()),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterDropdown() {
    return Padding(
      padding: const EdgeInsets.only(right: 4),
      child: StyledDropdown(
        selectedValue: _selectedPlanet,
        items: _planetList,
        hintText: "பிளானெட் மூலம் வடிகட்டி",
      ),
    );
  }

  Widget _buildTable() {
    return StreamBuilder<QuerySnapshot>(
      stream: _getPlanetStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('பிழை: ${snapshot.error}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        return ValueListenableBuilder<String?>(
          valueListenable: _selectedPlanet,
          builder: (context, selectedPlanet, _) {
            return CommonNotesTable(
              docs: docs,
              selectedValue: selectedPlanet,
              filterKey: "planet", // ← Firestore field key
              defaultLabel: "சூரியன்",
              zoom: widget.zoom,// ← Default selected planet
            );
          },
        );
      },
    );
  }
}
