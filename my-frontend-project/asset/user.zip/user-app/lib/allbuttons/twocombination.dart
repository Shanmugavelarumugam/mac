import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class Twocombination extends StatefulWidget {
  @override
  _TwocombinationDisplayState createState() => _TwocombinationDisplayState();
}

class _TwocombinationDisplayState extends State<Twocombination> {
  final ValueNotifier<String?> _selectedStarNotifier = ValueNotifier<String?>(
    "சூரி+ சந்",
  );

  final List<String> planetaryCombinations = [
    'சூரி+ சந்',
    'சூரி+ செவ்',
    'சூரி+ புத',
    'சூரி+ குரு',
    'சூரி+ சுக்',
    'சூரி+ சனி',
    'சூரி+ ரா',
    'சூரி+ கே',
    'சந் + செவ்',
    'சந் + புத',
    'சந் + குரு',
    'சந் + சுக்',
    'சந் + சனி',
    'சந் + ரா',
    'சந் + கே',
    'செவ் + புத',
    'செவ் + குரு',
    'செவ் + சுக்',
    'செவ் + சனி',
    'செவ் + ரா',
    'செவ் + கே',
    'புத + குரு',
    'புத + சுக்',
    'புத + சனி',
    'புத + ரா',
    'புத + கே',
    'குரு + சுக்',
    'குரு + சனி',
    'குரு + ரா',
    'குரு + கே',
    'சுக் + சனி',
    'சுக் + ரா',
    'சுக் + கே',
    'சனி + ரா',
    'சனி + கே',
  ];

  Stream<QuerySnapshot> _getStarStream() {
    return FirebaseFirestore.instance
        .collection('twocombination')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  void dispose() {
    _selectedStarNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(16.0),
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          SizedBox(height: 30),
          _buildFilterDropdown(),
          const SizedBox(height: 16),
          Expanded(child: _buildTable()),
        ],
      ),
    );
  }

  Widget _buildFilterDropdown() {
    return Container(
      width: 300,
      padding: EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
      ),
      child: DropdownButtonHideUnderline(
        child: ValueListenableBuilder<String?>(
          valueListenable: _selectedStarNotifier,
          builder: (context, selectedStar, _) {
            return DropdownButton<String>(
              value:
                  planetaryCombinations.contains(selectedStar)
                      ? selectedStar
                      : null,
              isExpanded: true,
              onChanged: (value) {
                _selectedStarNotifier.value = value;
              },
              items:
                  planetaryCombinations
                      .map(
                        (planet) => DropdownMenuItem(
                          value: planet,
                          child: Text(
                            planet,
                            style: TextStyle(
                              color: Color.fromARGB(255, 244, 103, 60),
                            ),
                          ),
                        ),
                      )
                      .toList(),
            );
          },
        ),
      ),
    );
  }

  Widget _buildTable() {
    return StreamBuilder<QuerySnapshot>(
      stream: _getStarStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('பிழை ஏற்பட்டது: ${snapshot.error}'));
        }

        if (!snapshot.hasData) {
          return Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        return ValueListenableBuilder<String?>(
          valueListenable: _selectedStarNotifier,
          builder: (context, selectedStar, _) {
            final filteredDocs =
                docs.where((doc) {
                  final data = doc.data() as Map<String, dynamic>;
                  return data['two'] == selectedStar;
                }).toList();

            if (filteredDocs.isEmpty) {
              return Center(
                child: Text(
                  "தேர்ந்தெடுக்கப்பட்ட கிரகம் தொடர்புடைய குறிப்புகள் இல்லை.",
                ),
              );
            }

            return SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Table(
                columnWidths: const {
                  0: FixedColumnWidth(40),
                  1: FlexColumnWidth(),
                },
                border: TableBorder.all(
                  color: Color.fromARGB(255, 244, 103, 60),
                ),
                children: [
                  TableRow(
                    decoration: BoxDecoration(
                      color: Color.fromARGB(255, 244, 103, 60),
                    ),
                    children: [
                      Padding(
                        padding: EdgeInsets.all(8),
                        child: Text(
                          "",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.deepOrange,
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(8),
                        child: Text(
                          selectedStar ?? "தேர்வு செய்யப்படவில்லை",
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                  ...filteredDocs.asMap().entries.map((entry) {
                    final index = entry.key + 1;
                    final data = entry.value.data() as Map<String, dynamic>;
                    final notes = data['notes'] ?? '';

                    return TableRow(
                      children: [
                        Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(
                            index.toString(),
                            style: TextStyle(
                              color: Color.fromARGB(255, 244, 103, 60),
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(
                            notes,
                            softWrap: true,
                            style: TextStyle(
                              color: Color.fromARGB(255, 244, 103, 60),
                            ),
                          ),
                        ),
                      ],
                    );
                  }).toList(),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
