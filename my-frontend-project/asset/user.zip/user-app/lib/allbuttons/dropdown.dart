import 'package:flutter/material.dart';

class StyledDropdown extends StatelessWidget {
  final ValueNotifier<String?> selectedValue;
  final List<String> items;
  final String hintText;

  const StyledDropdown({
    Key? key,
    required this.selectedValue,
    required this.items,
    required this.hintText,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isLandscape =
        MediaQuery.of(context).orientation == Orientation.landscape;

    return Transform.translate(
      offset: isLandscape ? const Offset(0, -3) : const Offset(0, -2),
      child: ValueListenableBuilder<String?>(
        valueListenable: selectedValue,
        builder: (context, selected, _) {
          return IntrinsicWidth(
            child: Container(
              //constraints: const BoxConstraints(minWidth: 150, maxWidth: 280),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFEF5350), Color(0xFFFF7043)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.orange.withOpacity(0.35),
                    offset: const Offset(0, 5),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: SizedBox(
                height: 30,
                width: MediaQuery.sizeOf(context).width,
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    dropdownColor: const Color(0xFFFFF3E0),
                    icon: AnimatedRotation(
                      turns: selected == null ? 0 : 0.5,
                      duration: const Duration(milliseconds: 350),
                      curve: Curves.easeInOut,
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 250),
                        child: Icon(
                          selected == null
                              ? Icons.keyboard_arrow_down_rounded
                              : Icons.keyboard_arrow_up_rounded,
                          key: ValueKey<bool>(selected != null),
                          color: Colors.white,
                          size: 22,
                        ),
                      ),
                    ),
                    value: selected,
                    isExpanded: true,
                    hint: Text(
                      hintText,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    style: TextStyle(
                      color: Colors.deepOrange.shade900,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                    ),
                    onChanged: (value) {
                      selectedValue.value = value;
                    },
                    items:
                        items.map((item) {
                          return DropdownMenuItem<String>(
                            value: item,
                            child: Padding(
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              child: Text(
                                item,
                                style: TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.deepOrange.shade800,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                    selectedItemBuilder: (context) {
                      return items.map((item) {
                        return Row(
                          children: [
                            Flexible(
                              child: Text(
                                item,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        );
                      }).toList();
                    },
                    menuMaxHeight: 600,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
