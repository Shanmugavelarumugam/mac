import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CommonNotesTable extends StatelessWidget {
  final List<QueryDocumentSnapshot> docs;
  final String? selectedValue;
  final String filterKey;
  final String defaultLabel;
  final double zoom;

  const CommonNotesTable({
    super.key,
    required this.docs,
    required this.selectedValue,
    required this.filterKey,
    required this.defaultLabel,
    this.zoom=1.0
  });

  @override
  Widget build(BuildContext context) {
    final filtered = (selectedValue == defaultLabel)
        ? docs
        : docs.where((d) {
      final m = (d.data() as Map<String, dynamic>);
      return m[filterKey] == selectedValue;
    }).toList();

    if (filtered.isEmpty) {
      return const Padding(
        padding: EdgeInsets.all(14),
        child: Center(
          child: Text(
            "தேர்ந்தெடுக்கப்பட்ட பொருளுக்கு குறிப்புகள் இல்லை.",
            style: TextStyle(fontSize: 14),
          ),
        ),
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        const baseRows = 8;
        const step = 0.1;

        final scale = _currentScale(context);
        final addRows = scale < 1.0 ? ((1.0 - scale) / step).floor() : 0;
        final rowsToShow = (baseRows + addRows).clamp(0, filtered.length);

        final basePadding = 6.0;
        final reducedPadding = scale < 1.0 ? (basePadding - 2).clamp(2.0, basePadding) : basePadding;

        final table = Table(
          columnWidths: const {0: FlexColumnWidth()},
          border: TableBorder.symmetric(
            inside: const BorderSide(color: Colors.grey, width: 0.8,),
            borderRadius: BorderRadius.circular(5)
          ),
          children: filtered.take(rowsToShow).map((d) {
            final text = ((d.data() as Map<String, dynamic>)['notes'] ?? 'குறிப்பு இல்லை').toString();
            return TableRow(
              decoration: const BoxDecoration(color: Colors.white),
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(
                    vertical: 3,
                    horizontal: 4,
                  ),
                  child: Text(
                    text,
                    style: const TextStyle(fontSize: 10, color: Color(0xFFFF7043), ),
                  ),
                ),
              ],
            );
          }).toList(),
        );

        return Container(
          margin: const EdgeInsets.only(right: 8),
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: table,
          ),
        );
      },
    );
  }

  double _currentScale(BuildContext context) {
    final renderBox = context.findRenderObject();
    if (renderBox is RenderBox) {
      final mat = renderBox.getTransformTo(null);
      return mat.storage.isNotEmpty ? mat.storage[0] : 1.0;
    }
    return 1.0;
  }
}
