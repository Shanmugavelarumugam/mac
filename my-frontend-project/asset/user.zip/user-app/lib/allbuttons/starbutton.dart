import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/allbuttons/common_notes_table.dart';
import 'package:usertest/allbuttons/dropdown.dart';

class Starsdisplay extends StatefulWidget {
  final ValueNotifier<String?>? notifier;
  final double zoom;//
  const Starsdisplay({Key? key, this.notifier, required this.zoom}) : super(key: key);

  @override
  _StardisplayState createState() => _StardisplayState();
}

class _StardisplayState extends State<Starsdisplay> {
  late final ValueNotifier<String?> _selectedStarNotifier;
  bool _ownsNotifier = false;

  final List<String> _starList = [
    "அஷ்வினி",
    "பரணி",
    "கார்த்திகை",
    "ரோகிணி",
    "மிருகசீரிடம்",
    "திருவாதிரை",
    "புனர்பூசம்",
    "பூசம்",
    "ஆயில்யம்",
    "மகம்",
    "பூரம்",
    "உத்திரம்",
    "ஹஸ்தம்",
    "சித்திரை",
    "சுவாதி",
    "விசாகம்",
    "அனுஷம்",
    "கேட்டை",
    "மூலம்",
    "பூராடம்",
    "உத்திராடம்",
    "திருவோணம்",
    "அவிட்டம்",
    "சதயம்",
    "பூரட்டாதி",
    "உத்திரட்டாதி",
    "ரேவதி",
  ];

  @override
  void initState() {
    super.initState();
    if (widget.notifier != null) {
      _selectedStarNotifier = widget.notifier!;
    } else {
      _selectedStarNotifier = ValueNotifier<String?>("அஷ்வினி");
      _ownsNotifier = true;
    }
  }

  @override
  void dispose() {
    if (_ownsNotifier) {
      _selectedStarNotifier.dispose();
    }
    super.dispose();
  }

  Stream<QuerySnapshot> _getStarStream() {
    return FirebaseFirestore.instance
        .collection('star')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      width: MediaQuery.sizeOf(context).width,
      child: Column(
        children: [
           const SizedBox(height: 10),
          ValueListenableBuilder<String?>(
            valueListenable: _selectedStarNotifier,
            builder: (context, selectedStar, _) {
              return _buildFilterDropdown();
            },
          ),
          Expanded(
            child: ValueListenableBuilder<String?>(
              valueListenable: _selectedStarNotifier,
              builder: (context, selectedStar, _) {
                return _buildTable(selectedStar);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterDropdown() {
    return Padding(
      padding: const EdgeInsets.only(right: 4),
      child: StyledDropdown(
        selectedValue: _selectedStarNotifier,
        items: _starList,
        hintText: "அஷ்வினி",
      ),
    );
  }

  Widget _buildTable(String? selectedStar) {
    return StreamBuilder<QuerySnapshot>(
      stream: _getStarStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(child: Text('பிழை ஏற்பட்டது'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        return CommonNotesTable(
          docs: docs,
          selectedValue: selectedStar,
          filterKey: "star",
          defaultLabel: "அஷ்வினி",
          zoom: widget.zoom,
        );
      },
    );
  }
}
