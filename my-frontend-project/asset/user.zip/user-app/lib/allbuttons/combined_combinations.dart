import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/allbuttons/common_notes_table.dart';
import 'package:usertest/allbuttons/dropdown.dart';

class CombinedCombinationDisplay extends StatefulWidget {
  final ValueNotifier<String?>? notifier;
  final double zoom;//

  const CombinedCombinationDisplay({Key? key, this.notifier, required this.zoom}) : super(key: key);

  @override
  _CombinedCombinationDisplayState createState() =>
      _CombinedCombinationDisplayState();
}

class _CombinedCombinationDisplayState
    extends State<CombinedCombinationDisplay> {
  late final ValueNotifier<String?> _selectedCombo;

  final List<String> _allCombinations = [
    // Two combinations
    'சூரி+ சந்',
    'சூரி+ செவ்',
    'சூரி+ புத',
    'சூரி+ குரு',
    'சூரி+ சுக்',
    'சூரி+ சனி',
    'சூரி+ ரா',
    'சூரி+ கே',
    'சந் + செவ்',
    'சந் + புத',
    'சந் + குரு',
    'சந் + சுக்',
    'சந் + சனி',
    'சந் + ரா',
    'சந் + கே',
    'செவ் + புத',
    'செவ் + குரு',
    'செவ் + சுக்',
    'செவ் + சனி',
    'செவ் + ரா',
    'செவ் + கே',
    'புத + குரு',
    'புத + சுக்',
    'புத + சனி',
    'புத + ரா',
    'புத + கே',
    'குரு + சுக்',
    'குரு + சனி',
    'குரு + ரா',
    'குரு + கே',
    'சுக் + சனி',
    'சுக் + ரா',
    'சுக் + கே',
    'சனி + ரா',
    'சனி + கே',

    // Three combinations
    'சூரி + சந் + செவ்',
    'சூரி + சந்+ புத',
    'சூரி + சந்+ குரு',
    'சூரி + சந் + சுக்',
    'சூரி + சந் + சனி',
    'சூரி + சந் + ரா',
    'சூரி + சந் + கே',
    'சூரி + செவ் + புத',
    'சூரி + செவ் + குரு',
    'சூரி + செவ் + சுக்',
    'சூரி + செவ் + சனி',
    'சூரி + செவ் + ரா',
    'சூரி + செவ் + கே',
    'சூரி + புத + குரு',
    'சூரி + புத + சுக்',
    'சூரி + புத + சனி',
    'சூரி + புத + ரா',
    'சூரி + புத + கே',
    'சூரி + குரு + சுக்',
    'சூரி + குரு + சனி',
    'சூரி + குரு + ரா',
    'சூரி + குரு + கே',
    'சூரி + சுக் + சனி',
    'சூரி + சுக் + ரா',
    'சூரி + சுக் + கே',
    'சூரி + சனி + ரா',
    'சூரி + சனி + கே',
    'சந் + செவ் + புத',
    'சந் + செவ் + குரு',
    'சந் + செவ் + சுக்',
    'சந் + செவ் + சனி',
    'சந் + செவ் + ரா',
    'சந் + செவ் + கே',
    'சந் + புத + குரு',
    'சந் + புத + சுக்',
    'சந் + புத + சனி',
    'சந் + புத + ரா',
    'சந் + புத + கே',
    'சந் + குரு + சுக்',
    'சந் + குரு + சனி',
    'சந் + குரு + ரா',
    'சந் + குரு + கே',
    'சந் + சுக் + சனி',
    'சந் + சுக் + ரா',
    'சந் + சுக் + கே',
    'சந் + சனி + ரா',
    'சந் + சனி + கே',
    'செவ் + புத + குரு',
    'செவ் + புத + சுக்',
    'செவ் + புத + சனி',
    'செவ் + புத + ரா',
    'செவ் + புத + கே',
    'செவ் + குரு + சுக்',
    'செவ் + குரு + சனி',
    'செவ் + குரு + ரா',
    'செவ் + குரு + கே',
    'செவ் + சுக் + சனி',
    'செவ் + சுக் + ரா',
    'செவ் + சுக் + கே',
    'செவ் + சனி + ரா',
    'செவ் + சனி + கே',
    'புத + குரு + சுக்',
    'புத + குரு + சனி',
    'புத + குரு + ரா',
    'புத + குரு + கே',
    'புத + சுக் + சனி',
    'புத + சுக் + ரா',
    'புத + சுக் + கே',
    'புத + சனி + ரா',
    'புத + சனி + கே',
    'குரு + சுக் + சனி',
    'குரு + சுக் + ரா',
    'குரு + சுக் + கே',
    'குரு + சனி + ரா',
    'குரு + சனி + கே',
    ' சுக் + சனி + ரா',
    ' சுக் + சனி + கே',
    'சனி + ரா + கே',
  ];

  bool _isTwoCombination(String combo) {
    return combo.contains('+') && combo.split('+').length == 2;
  }

  Stream<QuerySnapshot> _getComboStream() {
    final selected = _selectedCombo.value ?? _allCombinations.first;
    final isTwo = _isTwoCombination(selected);
    final collection = isTwo ? 'twocombination' : 'threecombination';
    return FirebaseFirestore.instance
        .collection(collection)
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  void initState() {
    super.initState();
    _selectedCombo = widget.notifier ?? ValueNotifier(_allCombinations.first);
  }

  @override
  void dispose() {
    if (widget.notifier == null) {
      _selectedCombo.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        color: Colors.white,
        width: MediaQuery.sizeOf(context).width,
        child: Column(
          children: [
             const SizedBox(height: 10),
             _buildFilterDropdown(),
            Expanded(child: _buildTable()),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterDropdown() {
    return StyledDropdown(
      selectedValue: _selectedCombo,
      items: _allCombinations,
      hintText: "கிரகக் கூட்டம் மூலம் வடிகட்டி",
    );
  }

  Widget _buildTable() {
    return StreamBuilder<QuerySnapshot>(
      stream: _getComboStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(child: Text('பிழை ஏற்பட்டது'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        return ValueListenableBuilder<String?>(
          valueListenable: _selectedCombo,
          builder: (context, selectedCombo, _) {
            final isTwo = _isTwoCombination(selectedCombo ?? '');
            final key = isTwo ? 'two' : 'three';

            return CommonNotesTable(
              docs: docs,
              selectedValue: selectedCombo ?? _allCombinations.first,
              filterKey: key,
              defaultLabel: "கிரகக் கூட்டம்",
              zoom: widget.zoom,
            );
          },
        );
      },
    );
  }
}
