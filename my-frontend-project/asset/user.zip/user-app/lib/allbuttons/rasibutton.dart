import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/allbuttons/common_notes_table.dart';
import 'package:usertest/allbuttons/dropdown.dart';

class RasiDisplay extends StatefulWidget {
  final ValueNotifier<String?>? notifier;
  final double zoom;//

  const RasiDisplay({Key? key, this.notifier, required this.zoom}) : super(key: key);

  @override
  _RasiDisplayState createState() => _RasiDisplayState();
}

class _RasiDisplayState extends State<RasiDisplay> {
  late final ValueNotifier<String?> _selectedRasi;

  final List<String> _rasiList = [
    'மேஷம்',
    'ரிஷபம்',
    'மிதுனம்',
    'கடகம்',
    'சிம்மம்',
    'கன்னி',
    'துலாம்',
    'விருச்சிகம்',
    'தனுசு',
    'மகரம்',
    'கும்பம்',
    'மீனம்',
  ];

  Stream<QuerySnapshot> _getRasiStream() {
    return FirebaseFirestore.instance
        .collection('service_notes')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  void initState() {
    super.initState();
    _selectedRasi = widget.notifier ?? ValueNotifier('மேஷம்');
  }

  @override
  void dispose() {
    if (widget.notifier == null) {
      _selectedRasi.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        color: Colors.white,
        width: MediaQuery.sizeOf(context).width,
        child: Column(
          children: [
             const SizedBox(height: 10),
             _buildFilterDropdown(),
            Expanded(child: _buildTable()),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterDropdown() {
    return Padding(
      padding: const EdgeInsets.only(right: 4),
      child: StyledDropdown(
        selectedValue: _selectedRasi,
        items: _rasiList,
        hintText: "ராசி மூலம் வடிகட்டி",
      ),
    );
  }

  Widget _buildTable() {
    return StreamBuilder<QuerySnapshot>(
      stream: _getRasiStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return const Center(child: Text('பிழை ஏற்பட்டது'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        return ValueListenableBuilder<String?>(
          valueListenable: _selectedRasi,
          builder: (context, selectedRasi, _) {
            return CommonNotesTable(
              docs: docs,
              selectedValue: selectedRasi ?? "மேஷம்",
              filterKey: "rasi",
              defaultLabel: "மேஷம்",
              zoom: widget.zoom,
            );
          },
        );
      },
    );
  }
}
