import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:usertest/datadisplay/bookmark.dart';
import 'package:usertest/login/login.dart';
import 'package:usertest/profile/profile.dart';

class Sidebar extends StatelessWidget {
  const Sidebar({super.key});

  final String facebookUrl = 'https://www.facebook.com/rk.astro.485327';
  final String youtubeUrl = 'https://www.youtube.com/@AstroRam786';
  final String whatsapp =
      'https://wa.me/91944424857210?text=Hello%20RK%20Astro%2C%20I%20need%20astrology%20support';

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final displayName = user?.displayName ?? 'RK Astro User';

    return Drawer(
      child: Container(
        color: Colors.white,
        child: Column(
          children: [
            const SizedBox(height: 30),

            // Greeting

            // Logo
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.asset(
                  'assets/rka.png',
                  height: 180,
                  width: 180,
                  fit: BoxFit.contain,
                ),
              ),
            ),

            const SizedBox(height: 10),

            // Navigation Items
            _sidebarCard(Icons.person_3_outlined, "Profile", () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const Profile()),
              );
            }),

            _sidebarCard(Icons.bookmark_outline, "Bookmarks", () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => BookmarksScreen()),
              );
            }),

            // 🔽 Show bookmarks inline below the Bookmarks tile
            StreamBuilder(
              stream:
                  FirebaseFirestore.instance
                      .collection('bookmarks')
                      .where('uid', isEqualTo: user?.uid)
                      .orderBy('timestamp', descending: true)
                      .limit(5)
                      .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20.0),
                  );
                }

                return Column(
                  children:
                      snapshot.data!.docs.map((doc) {
                        final data = doc.data() as Map<String, dynamic>;
                        final combo =
                            '${data['lagnam']}, ${data['bhavam']}, ${data['planet']}, ${data['rasi']}, ${data['star']}';
                        return const SizedBox.shrink();
                        ();
                      }).toList(),
                );
              },
            ),

            _sidebarCard(Icons.logout_outlined, "Sign Out", () async {
              await FirebaseAuth.instance.signOut();
              Navigator.of(context).pop();
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (_) => const LoginScreen()),
              );
            }),

            const SizedBox(height: 400),

            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16.0),
              child: Text(
                'Follow us on',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.deepOrange,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            const SizedBox(height: 5),

            // Social Media Row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                GestureDetector(
                  onTap: () => _launchURL(facebookUrl),
                  child: const Icon(
                    Icons.facebook,
                    size: 50,
                    color: Colors.blue,
                  ),
                ),
                GestureDetector(
                  onTap: () => _launchURL(youtubeUrl),
                  child: Image.asset(
                    'assets/youtubepng.png',
                    height: 60,
                    width: 50,
                  ),
                ),
                GestureDetector(
                  onTap: () => _launchURL(whatsapp),
                  child: Image.asset(
                    'assets/whatsappbg.png',
                    height: 60,
                    width: 50,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 15),
            Text(
              "© 2025 RK Astro",
              style: TextStyle(color: Colors.grey.shade600, fontSize: 12),
            ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  // Sidebar Tile Widget
  Widget _sidebarCard(IconData icon, String title, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(15),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF3E0),
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                color: Colors.orange.shade100,
                blurRadius: 6,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              Icon(icon, color: Colors.deepOrange, size: 24),
              const SizedBox(width: 16),
              Text(
                title,
                style: const TextStyle(
                  color: Colors.black87,
                  fontSize: 18,
                  letterSpacing: 0.5,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // URL Launcher
  void _launchURL(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw 'Could not launch $url';
    }
  }
}
