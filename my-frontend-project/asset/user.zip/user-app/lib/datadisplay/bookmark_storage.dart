// class BookmarkStorage {
//   static final BookmarkStorage _instance = BookmarkStorage._internal();
//   factory BookmarkStorage() => _instance;
//   BookmarkStorage._internal();

//   final Set<String> _bookmarks = {};

//   Set<String> get bookmarks => _bookmarks;

//   void add(String item) => _bookmarks.add(item);
//   void remove(String item) => _bookmarks.remove(item);
//   bool contains(String item) => _bookmarks.contains(item);
// }
