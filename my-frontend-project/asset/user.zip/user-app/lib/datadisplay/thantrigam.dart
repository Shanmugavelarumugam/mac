import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class Thantrigam extends StatefulWidget {
  @override
  _thantrigamDisplayState createState() => _thantrigamDisplayState();
}

class _thantrigamDisplayState extends State<Thantrigam> {
  Stream<QuerySnapshot> _getParvaiStream() {
    return FirebaseFirestore.instance
        .collection('thantrigam')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
    
      appBar: AppBar(
        
      ),
      body: Container(
        margin: const EdgeInsets.all(16.0),
        padding: const EdgeInsets.all(16.0),
        child: _buildTable(),
      ),
    );
  }

  Widget _buildTable() {
    return StreamBuilder<QuerySnapshot>(
      stream: _getParvaiStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('பிழை: ${snapshot.error}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        if (docs.isEmpty) {
          return const Center(
            child: Text("பதிவுகள் எதுவும் இல்லை."),
          );
        }

        return SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Table(
            columnWidths: const {
              0: FixedColumnWidth(50), // S.No column
              1: FlexColumnWidth(),    // Notes column
            },
            border: TableBorder.all(
              color: const Color.fromARGB(255, 244, 103, 60),
            ),
            children: [
              TableRow(
                decoration: const BoxDecoration(
                  color: Color.fromARGB(255, 244, 103, 60),
                ),
                children: [
                  _tableHeader(" "),
                  _tableHeader("தாந்திரிகம்"),
                ],
              ),
              ...docs.asMap().entries.map((entry) {
                final index = entry.key + 1;
                final data = entry.value.data() as Map<String, dynamic>;
                final parvai = data['note']?.toString().trim() ?? 'குறிப்பு இல்லை';

                return TableRow(
                  children: [
                    _tableCell(index.toString()),
                    _tableCell(parvai),
                  ],
                );
              }).toList(),
            ],
          ),
        );
      },
    );
  }

  Widget _tableHeader(String text) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Text(
        text,
        style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
      ),
    );
  }

  Widget _tableCell(String text) {
    return Padding(
      padding: const EdgeInsets.all(4.5),
      child: Text(
        text,
        style: const TextStyle(color: Color.fromARGB(255, 244, 103, 60)),
      ),
    );
  }
}
