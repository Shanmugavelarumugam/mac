import 'package:flutter/material.dart';

class StylishDropdown extends StatelessWidget {
  final ValueNotifier<String?> selectedValue;
  final List<String> items;
  final String defaultValue;

  const StylishDropdown({
    super.key,
    required this.selectedValue,
    required this.items,
    this.defaultValue = "மேஷம் லக்னம்",
  });

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String?>(
      valueListenable: selectedValue,
      builder: (context, value, child) {
        return Container(
          width: 250,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFF7043), Color(0xFFFF8A65)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.orange.withOpacity(0.35),
                offset: const Offset(0, 6),
                blurRadius: 10,
              ),
            ],
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              dropdownColor: const Color(0xFFFFF3E0),
              icon: AnimatedRotation(
                turns: value == null ? 0 : 0.5,
                duration: const Duration(milliseconds: 300),
                child: const Icon(
                  Icons.keyboard_arrow_up_rounded,
                  color: Colors.white,
                  size: 26,
                ),
              ),
              value: value,
              isExpanded: true,
              style: TextStyle(
                color: Colors.deepOrange.shade900,
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
              onChanged: (val) => selectedValue.value = val,
              items:
                  items.map((item) {
                    return DropdownMenuItem(
                      value: item,
                      child: Text(
                        item,
                        style: const TextStyle(fontWeight: FontWeight.w500),
                      ),
                    );
                  }).toList(),
              selectedItemBuilder: (context) {
                return items.map((item) {
                  return Row(
                    children: [
                      Text(
                        item,
                        style: const TextStyle(
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  );
                }).toList();
              },
            ),
          ),
        );
      },
    );
  }
}
