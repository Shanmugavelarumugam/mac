import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/dashboard/dashboard.dart';

class Threecombination extends StatefulWidget {
  @override
  _ThreecombinationdisplayState createState() =>
      _ThreecombinationdisplayState();
}

class _ThreecombinationdisplayState extends State<Threecombination> {
  final ValueNotifier<String?> _selectedStarNotifier = ValueNotifier<String?>("சூரி + சந் + செவ்");

  final List<String> planetCombinations = [
    'சூரி + சந் + செவ்',
    'சூரி + சந்+ புத',
    'சூரி + சந்+ குரு',
    'சூரி + சந் + சுக்',
    'சூரி + சந் + சனி',
    'சூரி + சந் + ரா',
    'சூரி + சந் + கே',
    'சூரி + செவ் + புத',
    'சூரி + செவ் + குரு',
    'சூரி + செவ் + சுக்',
    'சூரி + செவ் + சனி',
    'சூரி + செவ் + ரா',
    'சூரி + செவ் + கே',
    'சூரி + புத + குரு',
    'சூரி + புத + சுக்',
    'சூரி + புத + சனி',
    'சூரி + புத + ரா',
    'சூரி + புத + கே',
    'சூரி + குரு + சுக்',
    'சூரி + குரு + சனி',
    'சூரி + குரு + ரா',
    'சூரி + குரு + கே',
    'சூரி + சுக் + சனி',
    'சூரி + சுக் + ரா',
    'சூரி + சுக் + கே',
    'சூரி + சனி + ரா',
    'சூரி + சனி + கே',
    'சந் + செவ் + புத',
    'சந் + செவ் + குரு',
    'சந் + செவ் + சுக்',
    'சந் + செவ் + சனி',
    'சந் + செவ் + ரா',
    'சந் + செவ் + கே',
    'சந் + புத + குரு',
    'சந் + புத + சுக்',
    'சந் + புத + சனி',
    'சந் + புத + ரா',
    'சந் + புத + கே',
    'சந் + குரு + சுக்',
    'சந் + குரு + சனி',
    'சந் + குரு + ரா',
    'சந் + குரு + கே',
    'சந் + சுக் + சனி',
    'சந் + சுக் + ரா',
    'சந் + சுக் + கே',
    'சந் + சனி + ரா',
    'சந் + சனி + கே',
    'செவ் + புத + குரு',
    'செவ் + புத + சுக்',
    'செவ் + புத + சனி',
    'செவ் + புத + ரா',
    'செவ் + புத + கே',
    'செவ் + குரு + சுக்',
    'செவ் + குரு + சனி',
    'செவ் + குரு + ரா',
    'செவ் + குரு + கே',
    'செவ் + சுக் + சனி',
    'செவ் + சுக் + ரா',
    'செவ் + சுக் + கே',
    'செவ் + சனி + ரா',
    'செவ் + சனி + கே',
    'புத + குரு + சுக்',
    'புத + குரு + சனி',
    'புத + குரு + ரா',
    'புத + குரு + கே',
    'புத + சுக் + சனி',
    'புத + சுக் + ரா',
    'புத + சுக் + கே',
    'புத + சனி + ரா',
    'புத + சனி + கே',
    'குரு + சுக் + சனி',
    'குரு + சுக் + ரா',
    'குரு + சுக் + கே',
    'குரு + சனி + ரா',
    'குரு + சனி + கே',
    ' சுக் + சனி + ரா',
    ' சுக் + சனி + கே',
    'சனி + ரா + கே'
  ];

  Stream<QuerySnapshot> _getStarStream() {
    return FirebaseFirestore.instance
        .collection('threecombination')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  void dispose() {
    _selectedStarNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
    leading: IconButton(
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomePage()), // Replace with your actual dashboard widget
        );
      },
    ),
    
  ),
      body: Container(
        margin: const EdgeInsets.all(16.0),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
             SizedBox(height: 30,),
            _buildFilterDropdown(),
            const SizedBox(height: 16),
            Expanded(child: _buildTable()),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterDropdown() {
    return Container(
      width: 300,
      padding: EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
      color:Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
      ),
      child: DropdownButtonHideUnderline(
        child: ValueListenableBuilder<String?>(
          valueListenable: _selectedStarNotifier,
          builder: (context, selectedStar, _) {
            return DropdownButton<String>(
              value: planetCombinations.contains(selectedStar) ? selectedStar : null,
              isExpanded: true,
              onChanged: (value) {
                _selectedStarNotifier.value = value;
              },
              items: planetCombinations
                  .map((combination) =>
                      DropdownMenuItem(value: combination, child: Text(combination,style: TextStyle(color: Color.fromARGB(255, 244, 103, 60),),)))
                  .toList(),
            );
          },
        ),
      ),
    );
  }

  Widget _buildTable() {
    return StreamBuilder<QuerySnapshot>(
      stream: _getStarStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) return Center(child: Text('பிழை: ${snapshot.error}'));
        if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

        final docs = snapshot.data!.docs;

        return ValueListenableBuilder<String?>(
          valueListenable: _selectedStarNotifier,
          builder: (context, selectedStar, _) {
            final filteredDocs = docs
                .where((doc) =>
                    (doc.data() as Map<String, dynamic>)['three'] == selectedStar)
                .toList();

            if (filteredDocs.isEmpty) {
              return Center(child: Text("தேர்ந்தெடுத்த கூட்டு பற்றிய குறிப்புகள் இல்லை."));
            }

            return SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Table(
               columnWidths: const {
                  0: FixedColumnWidth(40), // Constant width of 40
                  1: FlexColumnWidth(), // Flexible remaining space
                },
                border: TableBorder.all(color: Colors.black26),
                children: [
                  TableRow(
                    decoration: BoxDecoration(
                    color: Color.fromARGB(255, 244, 103, 60),
                    ),
                    children: [
                      Padding(
                        padding: EdgeInsets.all(4.5),
                        child: Text("",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Color.fromARGB(255, 244, 103, 60),)),
                      ),
                      Padding(
                        padding: EdgeInsets.all(8),
                        child: Center(
                        child: Text(
                          selectedStar ?? "கூட்டு",
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.white),
                        ),
                      ),
                      ),
                    ],
                  ),
                  ...filteredDocs.asMap().entries.map((entry) {
                    final index = entry.key + 1;
                    final data = entry.value.data() as Map<String, dynamic>;
                    final notes = data['notes'] ?? '';

                    return TableRow(
                      children: [
                        Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(index.toString(),
                              style: TextStyle(color: Color.fromARGB(255, 244, 103, 60),)),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(notes,
                              softWrap: true, style: TextStyle(color: Color.fromARGB(255, 244, 103, 60),)),
                        ),
                      ],
                    );
                  }).toList(),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
