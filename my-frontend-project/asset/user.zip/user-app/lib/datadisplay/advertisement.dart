// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:usertest/dashboard/dashboard.dart';
// import 'package:usertest/datadisplay/addslider.dart';

// class HorizontalAdsScreen extends StatelessWidget {
//   final AdsSliderController controller = Get.put(AdsSliderController());

//   final List<Color> cardColors = [
//     Colors.green,
//     Colors.purple,
//     Colors.yellow,
//   ];

//   void showInProgressDialog(BuildContext context) {
//     showDialog(
//       context: context,
//       builder: (_) => AlertDialog(
//         title: Text("ஜாதகம்"),
//         content: Text("Sorry, we are in progress."),
//         actions: [
//           TextButton(
//             onPressed: () => Get.off(HomePage()),
//             child: Text("OK"),
//           )
//         ],
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return StreamBuilder<QuerySnapshot>(
//       stream: FirebaseFirestore.instance.collection('advertisement').snapshots(),
//       builder: (context, snapshot) {
//         if (snapshot.hasError) return Center(child: Text("Error: ${snapshot.error}"));
//         if (snapshot.connectionState == ConnectionState.waiting) return Center(child: CircularProgressIndicator());

//         final docs = snapshot.data!.docs;

//         return Column(
//           children: [
//             Container(
//               height: 150,
//               child: PageView.builder(
//                 controller: controller.pageController,
//                 itemCount: docs.length,
//                 onPageChanged: controller.onPageChanged,
//                 itemBuilder: (context, index) {
//                   final data = docs[index].data() as Map<String, dynamic>;
//                   final note = data['note'] ?? 'No description available';
//                   final cardColor = cardColors[index % cardColors.length];
//                   final isYellow = cardColor == Colors.yellow;
//                   final textColor = isYellow ? Colors.black : Colors.white;

//                   return Container(
//                     margin: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
//                     decoration: BoxDecoration(
//                       color: cardColor,
//                       borderRadius: BorderRadius.circular(12),
//                     ),
//                     padding: EdgeInsets.all(12),
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Expanded(
//                           child: Center(
//                             child: Text(
//                               note,
//                               textAlign: TextAlign.center,
//                               style: TextStyle(
//                                 fontSize: 14,
//                                 fontWeight: FontWeight.w600,
//                                 color: textColor,
//                               ),
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   );
//                 },
//               ),
//             ),
//             Obx(() {
//               return Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: List.generate(
//                   docs.length,
//                   (index) => AnimatedContainer(
//                     duration: Duration(milliseconds: 300),
//                     margin: EdgeInsets.symmetric(horizontal: 4),
//                     width: controller.currentIndex.value == index ? 12 : 8,
//                     height: 8,
//                     decoration: BoxDecoration(
//                       color: controller.currentIndex.value == index ? Colors.black : Colors.grey,
//                       shape: BoxShape.circle,
//                     ),
//                   ),
//                 ),
//               );
//             }),
//           ],
//         );
//       },
//     );
//   }
// }

import 'package:flutter/material.dart';

class HorizontalAdsScreen extends StatefulWidget {
  @override
  _HorizontalAdsScreenState createState() => _HorizontalAdsScreenState();
}

class _HorizontalAdsScreenState extends State<HorizontalAdsScreen> {
  final List<String> bannerImages = ['assets/image2.jpg', 'assets/image.jpg'];

  final PageController _pageController = PageController();
  int _currentIndex = 0;

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 160,
      child: Stack(
        children: [
          PageView.builder(
            controller: _pageController,
            itemCount: bannerImages.length,
            onPageChanged: (index) {
              setState(() {
                _currentIndex = index;
              });
            },
            itemBuilder: (context, index) {
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  image: DecorationImage(
                    image: AssetImage(bannerImages[index]),
                    fit: BoxFit.cover,
                  ),
                ),
              );
            },
          ),
          Positioned(
            bottom: 16,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                bannerImages.length,
                (index) => AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: _currentIndex == index ? 12 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color:
                        _currentIndex == index ? Colors.white : Colors.white70,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
