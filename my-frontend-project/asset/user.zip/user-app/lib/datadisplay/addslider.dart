import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AdsSliderController extends GetxController with GetTickerProviderStateMixin {
  final PageController pageController = PageController();
  final RxInt currentIndex = 0.obs;
  
  late AnimationController progressController; // for dot fill animation

  final int totalPages = 3;
  final int slideDurationSeconds = 3;

  @override
  void onInit() {
    super.onInit();

    // Animation controller runs from 0 to 1 in slideDurationSeconds
    progressController = AnimationController(
      vsync: this,
      duration: Duration(seconds: slideDurationSeconds),
    );

    // Start animation and listen to its status
    _startAutoSlide();
  }

  void _startAutoSlide() {
    progressController.forward();

    progressController.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        // When progress completes, move to next page and restart animation
        int nextPage = (currentIndex.value + 1) % totalPages;

        pageController.animateToPage(
          nextPage,
          duration: Duration(milliseconds: 500),
          curve: Curves.easeInOut,
        );

        currentIndex.value = nextPage;

        progressController.reset();
        progressController.forward();
      }
    });
  }

  void onPageChanged(int index) {
    currentIndex.value = index;
    // Restart the progress animation when page changes manually
    progressController.reset();
    progressController.forward();
  }

  @override
  void onClose() {
    progressController.dispose();
    pageController.dispose();
    super.onClose();
  }
}

class AdsSliderWidget extends StatelessWidget {
  final AdsSliderController controller = Get.put(AdsSliderController());

  final List<Widget> pages = [
    Center(child: Text('Front View 1', style: TextStyle(fontSize: 30))),
    Center(child: Text('Back View 2', style: TextStyle(fontSize: 30))),
    Center(child: Text('Front View 3', style: TextStyle(fontSize: 30))),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: PageView.builder(
            controller: controller.pageController,
            itemCount: pages.length,
            onPageChanged: controller.onPageChanged,
            itemBuilder: (_, index) => pages[index],
          ),
        ),
        SizedBox(height: 20),
        Obx(() => Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(pages.length, (index) {
            bool isCurrent = controller.currentIndex.value == index;
            return AnimatedDot(
              isActive: isCurrent,
              progress: isCurrent ? controller.progressController.value : 0,
            );
          }),
        )),
        SizedBox(height: 20),
      ],
    );
  }
}

class AnimatedDot extends StatelessWidget {
  final bool isActive;
  final double progress;

  const AnimatedDot({
    Key? key,
    required this.isActive,
    required this.progress,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Dot size
    double size = 12;

    return Container(
      margin: EdgeInsets.symmetric(horizontal: 6),
      width: size,
      height: size,
      child: Stack(
        children: [
          // Background dot (grey)
          Container(
            decoration: BoxDecoration(
              color: Colors.grey.shade300,
              shape: BoxShape.circle,
            ),
          ),
          // Foreground fill (blue, animated)
          ClipOval(
            child: Align(
              alignment: Alignment.centerLeft,
              widthFactor: progress,
              child: Container(
                color: Colors.blue,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
