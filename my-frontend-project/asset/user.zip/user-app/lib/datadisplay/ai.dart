import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/dashboard/dashboard.dart';

class AIdata extends StatefulWidget {
  @override
  _AIDisplayState createState() => _AIDisplayState();
}

class _AIDisplayState extends State<AIdata> {
  final ValueNotifier<String> _selectedLagnam = ValueNotifier("பொதுவான ஏ.ஐ");

  final List<String> _lagnamList = [
    'பொதுவான ஏ.ஐ',
    'மத்திய ஏ.ஐ',
    'மேம்பட்ட ஏ.ஐ',
  ];

  Stream<QuerySnapshot> _getLagnamStream() {
    return FirebaseFirestore.instance
        .collection('ai')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  void dispose() {
    _selectedLagnam.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => HomePage(),
              ), // Replace with your actual dashboard widget
            );
          },
        ),
      ),
      backgroundColor: Colors.white,
      body: Container(
        margin: const EdgeInsets.all(16.0),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            SizedBox(height: 30),
            _buildFilterDropdown(),
            const SizedBox(height: 16),
            Expanded(child: _buildTable()),
          ],
        ),
      ),
    );
  }

  // Dropdown for selecting the AI type
  Widget _buildFilterDropdown() {
    return Container(
      width: 250,
      padding: EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(12),
      ),
      child: ValueListenableBuilder<String>(
        valueListenable: _selectedLagnam,
        builder: (context, value, _) {
          return DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              hint: Text("ராசி மூலம் வடிகட்டி"),
              isExpanded: true,
              onChanged: (newValue) {
                if (newValue != null) {
                  _selectedLagnam.value = newValue;
                }
              },
              items:
                  _lagnamList
                      .map(
                        (lag) => DropdownMenuItem(
                          value: lag,
                          child: Text(
                            lag,
                            style: TextStyle(
                              color: const Color.fromARGB(255, 244, 103, 60),
                            ),
                          ),
                        ),
                      )
                      .toList(),
            ),
          );
        },
      ),
    );
  }

  // Table to display data from Firestore
  Widget _buildTable() {
    return ValueListenableBuilder<String>(
      valueListenable: _selectedLagnam,
      builder: (context, selectedLagnam, _) {
        return StreamBuilder<QuerySnapshot>(
          stream: _getLagnamStream(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(child: Text('பிழை: ${snapshot.error}'));
            }
            if (!snapshot.hasData) {
              return Center(child: CircularProgressIndicator());
            }

            final docs = snapshot.data!.docs;
            final filteredDocs =
                docs.where((doc) {
                  final data = doc.data() as Map<String, dynamic>;
                  final ai = data['ai']?.toString().trim();
                  return ai == selectedLagnam;
                }).toList();

            if (filteredDocs.isEmpty) {
              return Center(
                child: Text(
                  "தேர்ந்தெடுக்கப்பட்ட ஏ.ஐ வகைக்கான குறிப்புகள் இல்லை.",
                ),
              );
            }

            return ListView(
              children: [
                Table(
                  columnWidths: const {
                    0: FixedColumnWidth(40), // Constant width of 40
                    1: FlexColumnWidth(300), // Flexible remaining space
                  },
                  border: TableBorder.all(color: Colors.black26),
                  children: [
                    TableRow(
                      decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 244, 103, 60),
                      ),
                      children: [
                        Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(
                            " ",
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(
                            selectedLagnam,
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: const Color.fromARGB(255, 244, 103, 60),
                            ),
                          ),
                        ),
                      ],
                    ),
                    ...filteredDocs.asMap().entries.map((entry) {
                      final index = entry.key + 1;
                      final data = entry.value.data() as Map<String, dynamic>;
                      final notes = data['note'] ?? '';

                      return TableRow(
                        children: [
                          Padding(
                            padding: EdgeInsets.all(5),
                            child: Text(
                              index.toString(),
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.all(5),
                            child: Text(
                              notes,
                              softWrap: true,
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ],
                ),
              ],
            );
          },
        );
      },
    );
  }
}
