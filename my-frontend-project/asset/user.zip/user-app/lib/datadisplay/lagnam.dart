import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/allbuttons/common_notes_table.dart';
import 'package:usertest/allbuttons/dropdown.dart';
import 'package:usertest/datadisplay/stylish_dropdown.dart';
import 'package:usertest/widgets/CustomGradientAppBar.dart';
import 'package:usertest/dashboard/dashboard.dart';

class LagnamDisplay extends StatefulWidget {
  const LagnamDisplay({Key? key}) : super(key: key);

  @override
  _LagnamDisplayState createState() => _LagnamDisplayState();
}

class _LagnamDisplayState extends State<LagnamDisplay> {
  final ValueNotifier<String?> _selectedLagnamNotifier = ValueNotifier<String?>(
    'மேஷம் லக்னம்',
  );

  final List<String> _lagnamList = [
    'ரிஷபம் லக்னம்',
    'மிதுனம் லக்னம்',
    'கடகம் லக்னம்',
    'சிம்மம் லக்னம்',
    'கன்னி லக்னம்',
    'துலாம் லக்னம்',
    'விருச்சிகம் லக்னம்',
    'தனுசு லக்னம்',
    'மகரம் லக்னம்',
    'கும்பம் லக்னம்',
    'மீனம் லக்னம்',
  ];

  Stream<QuerySnapshot> _getLagnamStream() {
    return FirebaseFirestore.instance
        .collection('lagnam')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  void dispose() {
    _selectedLagnamNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    // Dynamic horizontal padding (more for tablets)
    final horizontalPadding =
        screenWidth > 600 ? screenWidth * 0.1 : screenWidth * 0.04;
    final topSpacing = screenHeight * 0.04;

    return Scaffold(
      appBar: CustomGradientAppBar(
        title: 'லக்னம் குறிப்புகள்',
        onBack: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const HomePage()),
          );
        },
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return Container(
              color: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
              child: Column(
                children: [
                  SizedBox(
                    height: topSpacing + 20,
                  ), // Increase by 20 pixels or whatever you want
                  _buildDropdownWithCountBadge(
                    constraints.maxWidth,
                    screenHeight,
                    screenWidth,
                  ),
                  SizedBox(height: screenHeight * 0),
                  Expanded(
                    child: SingleChildScrollView(child: _buildDataTable()),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildDropdownWithCountBadge(
    double maxWidth,
    double screenHeight,
    double screenWidth,
  ) {
    final combinationList = ['மேஷம் லக்னம்', ..._lagnamList];

    return ValueListenableBuilder<String?>(
      valueListenable: _selectedLagnamNotifier,
      builder: (context, selectedLagnam, _) {
        return StreamBuilder<QuerySnapshot>(
          stream: _getLagnamStream(),
          builder: (context, snapshot) {
            int count = 0;
            if (snapshot.hasData && selectedLagnam != null) {
              final docs = snapshot.data!.docs;
              count =
                  selectedLagnam == 'மேஷம் லக்னம்'
                      ? docs.length
                      : docs.where((doc) {
                        final data = doc.data() as Map<String, dynamic>;
                        return data['lagnam'] == selectedLagnam;
                      }).length;
            }

            return Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(
                      left: maxWidth * 0.04,
                    ), // moves dropdown right
                    child: StyledDropdown(
                      selectedValue: _selectedLagnamNotifier,
                      items: combinationList,
                      hintText: "லக்னம் தேர்வு செய்க",
                    ),
                  ),
                ),
                SizedBox(width: maxWidth * 0.09),
                _buildCountBadge(count, screenHeight, screenWidth),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildCountBadge(int count, double screenHeight, double screenWidth) {
    return Transform.translate(
      offset: Offset(
        0,
        -screenHeight * 0.025,
      ), // Moves up by 1.5% of screen height
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.04,
          vertical: screenHeight * 0.01,
        ),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF3E0),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.orange.withOpacity(0.3),
              blurRadius: 6,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(
              Icons.list_alt_rounded,
              color: Color(0xFFE65100),
              size: 20,
            ),
            SizedBox(width: screenWidth * 0.015),
            Text(
              "$count",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: screenWidth * 0.045,
                color: const Color(0xFFBF360C),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDataTable() {
    return ValueListenableBuilder<String?>(
      valueListenable: _selectedLagnamNotifier,
      builder: (context, selectedLagnam, _) {
        if (selectedLagnam == null) {
          return const Center(
            child: Text(
              "முதலில் ஒரு லக்னம் தேர்வு செய்க.",
              style: TextStyle(fontSize: 16),
            ),
          );
        }

        return StreamBuilder<QuerySnapshot>(
          stream: _getLagnamStream(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(child: Text('பிழை: ${snapshot.error}'));
            }
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }

            final filteredDocs =
                snapshot.data!.docs.where((doc) {
                  final data = doc.data() as Map<String, dynamic>;
                  if (selectedLagnam == 'மேஷம் லக்னம்') {
                    return true;
                  }
                  return data['lagnam'] == selectedLagnam;
                }).toList();

            return CommonNotesTable(
              docs: filteredDocs,
              selectedValue: selectedLagnam,
              filterKey: "lagnam",
              defaultLabel: "மேஷம் லக்னம்",
            );
          },
        );
      },
    );
  }
}
