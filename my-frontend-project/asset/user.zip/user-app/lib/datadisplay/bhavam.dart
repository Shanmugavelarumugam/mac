import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/dashboard/dashboard.dart';
import 'package:usertest/allbuttons/common_notes_table.dart';
import 'package:usertest/allbuttons/dropdown.dart';
import 'package:usertest/widgets/CustomGradientAppBar.dart';

class Bhavam extends StatefulWidget {
  const Bhavam({Key? key}) : super(key: key);

  @override
  _BhavamState createState() => _BhavamState();
}

class _BhavamState extends State<Bhavam> {
  final ValueNotifier<String?> _selectedBhavamNotifier = ValueNotifier<String?>(
    "முதல் பாவம்",
  );

  final List<String> _bhavamList = [
    'இரண்டாம் பாவம்',
    'மூன்றாம் பாவம்',
    'நான்காம் பாவம்',
    'ஐந்தாம் பாவம்',
    'ஆறாம் பாவம்',
    'ஏழாம் பாவம்',
    'எட்டாம் பாவம்',
    'ஒன்பதாம் பாவம்',
    'பத்தாம் பாவம்',
    'பதினொன்றாம் பாவம்',
    'பன்னிரண்டாம் பாவம்',
  ];

  Stream<QuerySnapshot> _getBhavamStream() {
    return FirebaseFirestore.instance
        .collection('bhavam')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  void dispose() {
    _selectedBhavamNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    final horizontalPadding =
        screenWidth > 600 ? screenWidth * 0.1 : screenWidth * 0.04;
    final topSpacing = screenHeight * 0.04;

    return Scaffold(
      appBar: CustomGradientAppBar(
        title: 'பாவம் குறிப்புகள்',
        onBack: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const HomePage()),
          );
        },
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return Container(
              color: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
              child: Column(
                children: [
                  SizedBox(height: topSpacing + 20),
                  _buildDropdownWithCountBadge(
                    constraints.maxWidth,
                    screenHeight,
                    screenWidth,
                  ),
                  SizedBox(height: screenHeight * 0),
                  Expanded(
                    child: SingleChildScrollView(child: _buildDataTable()),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildDropdownWithCountBadge(
    double maxWidth,
    double screenHeight,
    double screenWidth,
  ) {
    final bhavamListWithDefault = ["முதல் பாவம்", ..._bhavamList];

    return ValueListenableBuilder<String?>(
      valueListenable: _selectedBhavamNotifier,
      builder: (context, selectedBhavam, _) {
        return StreamBuilder<QuerySnapshot>(
          stream: _getBhavamStream(),
          builder: (context, snapshot) {
            int count = 0;
            if (snapshot.hasData && selectedBhavam != null) {
              final docs = snapshot.data!.docs;
              count =
                  selectedBhavam == "முதல் பாவம்"
                      ? docs.length
                      : docs.where((doc) {
                        final data = doc.data() as Map<String, dynamic>;
                        return data['bhavam'] == selectedBhavam;
                      }).length;
            }

            return Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(left: maxWidth * 0.04),
                    child: StyledDropdown(
                      selectedValue: _selectedBhavamNotifier,
                      items: bhavamListWithDefault,
                      hintText: "பாவத்தை தேர்ந்தெடுக்கவும்",
                    ),
                  ),
                ),
                SizedBox(width: maxWidth * 0.09),
                _buildCountBadge(count, screenHeight, screenWidth),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildCountBadge(int count, double screenHeight, double screenWidth) {
    return Transform.translate(
      offset: Offset(0, -screenHeight * 0.025),
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.04,
          vertical: screenHeight * 0.01,
        ),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF3E0),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.orange.withOpacity(0.3),
              blurRadius: 6,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(
              Icons.list_alt_rounded,
              color: Color(0xFFE65100),
              size: 20,
            ),
            SizedBox(width: screenWidth * 0.015),
            Text(
              "$count",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: screenWidth * 0.045,
                color: const Color(0xFFBF360C),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDataTable() {
    return ValueListenableBuilder<String?>(
      valueListenable: _selectedBhavamNotifier,
      builder: (context, selectedBhavam, _) {
        if (selectedBhavam == null) {
          return const Center(
            child: Text(
              "முதலில் ஒரு பாவத்தை தேர்ந்தெடுக்கவும்.",
              style: TextStyle(fontSize: 16),
            ),
          );
        }

        return StreamBuilder<QuerySnapshot>(
          stream: _getBhavamStream(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(child: Text('பிழை: ${snapshot.error}'));
            }
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }

            final filteredDocs =
                snapshot.data!.docs.where((doc) {
                  final data = doc.data() as Map<String, dynamic>;
                  if (selectedBhavam == "முதல் பாவம்") {
                    return true;
                  }
                  return data['bhavam'] == selectedBhavam;
                }).toList();

            return CommonNotesTable(
              docs: filteredDocs,
              selectedValue: selectedBhavam,
              filterKey: "bhavam",
              defaultLabel: "முதல் பாவம்",
            );
          },
        );
      },
    );
  }
}
