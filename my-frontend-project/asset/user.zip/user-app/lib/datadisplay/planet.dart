import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/dashboard/dashboard.dart';
import 'package:usertest/allbuttons/common_notes_table.dart';
import 'package:usertest/allbuttons/dropdown.dart';
import 'package:usertest/widgets/CustomGradientAppBar.dart';

class PlanetDisplay extends StatefulWidget {
  const PlanetDisplay({Key? key}) : super(key: key);

  @override
  _PlanetDisplayState createState() => _PlanetDisplayState();
}

class _PlanetDisplayState extends State<PlanetDisplay> {
  final ValueNotifier<String?> _selectedPlanet = ValueNotifier('சூரியன்');

  final List<String> _planetList = [
    'சூரியன்',
    'சந்திரன்',
    'செவ்வாய்',
    'புதன்',
    'குரு',
    'சுக்கிரன்',
    'சனி',
    'ராகு',
    'கேது',
  ];

  Stream<QuerySnapshot> _getPlanetStream() {
    return FirebaseFirestore.instance
        .collection('planet')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  void dispose() {
    _selectedPlanet.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    final horizontalPadding =
        screenWidth > 600 ? screenWidth * 0.1 : screenWidth * 0.04;
    final topSpacing = screenHeight * 0.04;
    return Scaffold(
      appBar: CustomGradientAppBar(
        title: "கிரகம்",
        onBack:
            () => Navigator.pushReplacement(
              context,
              MaterialPageRoute(builder: (context) => const HomePage()),
            ),
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return Container(
              color: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
              child: Column(
                children: [
                  SizedBox(height: topSpacing + 20),
                  _buildDropdownWithCountBadge(
                    constraints.maxWidth,

                    screenHeight,
                    screenWidth,
                  ),
                  SizedBox(height: screenHeight * 0),
                  Expanded(
                    child: SingleChildScrollView(child: _buildDataTable()),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildDropdownWithCountBadge(
    double width,
    double height,
    double screenWidth,
  ) {
    return ValueListenableBuilder<String?>(
      valueListenable: _selectedPlanet,
      builder: (context, selectedPlanet, _) {
        return StreamBuilder<QuerySnapshot>(
          stream: _getPlanetStream(),
          builder: (context, snapshot) {
            int count = 0;
            if (snapshot.hasData && selectedPlanet != null) {
              count =
                  snapshot.data!.docs
                      .where(
                        (doc) =>
                            (doc.data() as Map<String, dynamic>)['planet'] ==
                            selectedPlanet,
                      )
                      .length;
            }

            return Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(left: width * 0.20),
                    child: StyledDropdown(
                      selectedValue: _selectedPlanet,
                      items: _planetList,
                      hintText: "பிளானெட்டை தேர்வு செய்க",
                    ),
                  ),
                ),
                SizedBox(width: width * 0.09),
                _buildCountBadge(count, height, screenWidth),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildCountBadge(int count, double screenHeight, double screenWidth) {
    return Transform.translate(
      offset: Offset(0, -screenHeight * 0.03),
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.04,
          vertical: screenHeight * 0.01,
        ),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF3E0),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.orange.withOpacity(0.3),
              blurRadius: 6,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(
              Icons.list_alt_rounded,
              color: Color(0xFFE65100),
              size: 20,
            ),
            SizedBox(width: screenWidth * 0.015),
            Text(
              "$count",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: screenWidth * 0.045,
                color: const Color(0xFFBF360C),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDataTable() {
    return ValueListenableBuilder<String?>(
      valueListenable: _selectedPlanet,
      builder: (context, selectedPlanet, _) {
        if (selectedPlanet == null) {
          return const Center(
            child: Text(
              "முதலில் ஒரு பிளானெட்டைத் தேர்ந்தெடுக்கவும்.",
              style: TextStyle(fontSize: 16),
            ),
          );
        }

        return StreamBuilder<QuerySnapshot>(
          stream: _getPlanetStream(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(child: Text('பிழை: ${snapshot.error}'));
            }
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }

            final filteredDocs =
                selectedPlanet == 'சூரியன்'
                    ? snapshot.data!.docs
                    : snapshot.data!.docs.where((doc) {
                      final data = doc.data() as Map<String, dynamic>;
                      return data['planet'] == selectedPlanet;
                    }).toList();

            if (filteredDocs.isEmpty) {
              return Center(
                child: Text(
                  "தேர்ந்த பிளானெட்டிற்கான குறிப்புகள் எதுவும் கிடைக்கவில்லை.",
                  style: const TextStyle(fontSize: 16),
                ),
              );
            }

            return CommonNotesTable(
              docs: filteredDocs,
              selectedValue: selectedPlanet,
              filterKey: 'planet',
              defaultLabel: "கிரகம்",
            );
          },
        );
      },
    );
  }
}
