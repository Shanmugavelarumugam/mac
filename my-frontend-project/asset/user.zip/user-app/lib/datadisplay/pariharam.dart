import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/dashboard/dashboard.dart';

class Pariharam extends StatefulWidget {
  @override
  _PariharamDisplayState createState() => _PariharamDisplayState();
}

class _PariharamDisplayState extends State<Pariharam> {
  final ValueNotifier<String> selectedFilterType = ValueNotifier('அனைத்தும்');
  final List<String> _lagnamList = ['அனைத்தும்', 'ஜோதிடம்', 'வாஸ்து', 'பரிகாரம்'];
  Stream<QuerySnapshot> _getLagnamStream() {
    return FirebaseFirestore.instance
        .collection('pariharam')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
    leading: IconButton(
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomePage()), // Replace with your actual dashboard widget
        );
      },
    ),
    
  ),
      backgroundColor: Colors.white,
      body: Container(
        margin: const EdgeInsets.all(16.0),
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
             SizedBox(height: 30,),
            _buildFilterDropdown(),
            const SizedBox(height: 16),
            Expanded(child: _buildTable()),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterDropdown() {
    return ValueListenableBuilder<String>(
      valueListenable: selectedFilterType,
      builder: (context, value, _) {
        return Container(
          width: 250,
          padding: EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: Colors.grey[100],
            borderRadius: BorderRadius.circular(12),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: value,
              hint: Text("ராசி மூலம் வடிகட்டி"),
              isExpanded: true,
              onChanged: (newValue) {
                selectedFilterType.value = newValue!;
              },
              items: _lagnamList
                  .map(
                    (lag) => DropdownMenuItem(
                      value: lag,
                      child: Text(
                        lag,
                        style: TextStyle(
                          color: Color.fromARGB(255, 244, 103, 60),
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
        );
      },
    );
  }

  Widget _buildTable() {
    return StreamBuilder<QuerySnapshot>(
      stream: _getLagnamStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('பிழை: ${snapshot.error}'));
        }
        if (!snapshot.hasData) {
          return Center(child: CircularProgressIndicator());
        }

        return ValueListenableBuilder<String>(
          valueListenable: selectedFilterType,
          builder: (context, selectedLagnam, _) {
            final docs = snapshot.data!.docs;
            final filteredDocs = selectedLagnam == 'அனைத்தும்'
                ? docs
                : docs.where((doc) {
                    final data = doc.data() as Map<String, dynamic>;
                    final rasi = data['note']?.toString().trim();
                    return rasi == selectedLagnam;
                  }).toList();

            if (filteredDocs.isEmpty) {
              return Center(
                child: Text("தேர்ந்தெடுக்கப்பட்ட ராசிக்கான குறிப்புகள் இல்லை."),
              );
            }

            return SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Table(
                columnWidths: const {
                  0: FixedColumnWidth(50), // S.No column
                  1: FlexColumnWidth(),    // Notes column
                },
                border: TableBorder.all(
                  color: Color.fromARGB(255, 244, 103, 60),
                ),
                children: [
                  TableRow(
                    decoration: BoxDecoration(
                      color: Color.fromARGB(255, 244, 103, 60),
                    ),
                    children: [
                      _tableHeader(" "),
                      _tableHeader(selectedLagnam),
                    ],
                  ),
                  ...filteredDocs.asMap().entries.map((entry) {
                    final index = entry.key;
                    final data = entry.value.data() as Map<String, dynamic>;
                    final notes =
                        data['note']?.toString().trim() ?? 'குறிப்பு இல்லை';
                    return TableRow(
                      children: [
                        _tableCell((index + 1).toString()),
                        _tableCell(notes),
                      ],
                    );
                  }).toList(),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _tableHeader(String text) {
    return Padding(
      padding: EdgeInsets.all(8),
      child: Text(
        text,
        style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
      ),
    );
  }

  Widget _tableCell(String text) {
    return Padding(
      padding: EdgeInsets.all(4.5),
      child: Center(
        child: Text(
        text,
        style: TextStyle(color: Color.fromARGB(255, 244, 103, 60)),
      ),
      ),
    );
  }

  @override
  void dispose() {
    selectedFilterType.dispose();
    super.dispose();
  }
}
