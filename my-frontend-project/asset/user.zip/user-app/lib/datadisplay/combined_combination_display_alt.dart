import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/allbuttons/common_notes_table.dart';
import 'package:usertest/allbuttons/dropdown.dart';
import 'package:usertest/widgets/CustomGradientAppBar.dart';

class CombinedCombinationDisplayAlt extends StatefulWidget {
  final ValueNotifier<String?> notifier;

  const CombinedCombinationDisplayAlt({Key? key, required this.notifier})
    : super(key: key);

  @override
  _CombinedCombinationDisplayState createState() =>
      _CombinedCombinationDisplayState();
}

class _CombinedCombinationDisplayState
    extends State<CombinedCombinationDisplayAlt> {
  late ValueNotifier<String?> _selectedComboNotifier;

  final List<String> twoCombinations = [
  'சூரி+ சந்',
    'சூரி+ செவ்',
    'சூரி+ புத',
    'சூரி+ குரு',
    'சூரி+ சுக்',
    'சூரி+ சனி',
    'சூரி+ ரா',
    'சூரி+ கே',
    'சந் + செவ்',
    'சந் + புத',
    'சந் + குரு',
    'சந் + சுக்',
    'சந் + சனி',
    'சந் + ரா',
    'சந் + கே',
    'செவ் + புத',
    'செவ் + குரு',
    'செவ் + சுக்',
    'செவ் + சனி',
    'செவ் + ரா',
    'செவ் + கே',
    'புத + குரு',
    'புத + சுக்',
    'புத + சனி',
    'புத + ரா',
    'புத + கே',
    'குரு + சுக்',
    'குரு + சனி',
    'குரு + ரா',
    'குரு + கே',
    'சுக் + சனி',
    'சுக் + ரா',
    'சுக் + கே',
    'சனி + ரா',
    'சனி + கே',
  ];

  final List<String> threeCombinations = [
   'சூரி + சந் + செவ்',
    'சூரி + சந்+ புத',
    'சூரி + சந்+ குரு',
    'சூரி + சந் + சுக்',
    'சூரி + சந் + சனி',
    'சூரி + சந் + ரா',
    'சூரி + சந் + கே',
    'சூரி + செவ் + புத',
    'சூரி + செவ் + குரு',
    'சூரி + செவ் + சுக்',
    'சூரி + செவ் + சனி',
    'சூரி + செவ் + ரா',
    'சூரி + செவ் + கே',
    'சூரி + புத + குரு',
    'சூரி + புத + சுக்',
    'சூரி + புத + சனி',
    'சூரி + புத + ரா',
    'சூரி + புத + கே',
    'சூரி + குரு + சுக்',
    'சூரி + குரு + சனி',
    'சூரி + குரு + ரா',
    'சூரி + குரு + கே',
    'சூரி + சுக் + சனி',
    'சூரி + சுக் + ரா',
    'சூரி + சுக் + கே',
    'சூரி + சனி + ரா',
    'சூரி + சனி + கே',
    'சந் + செவ் + புத',
    'சந் + செவ் + குரு',
    'சந் + செவ் + சுக்',
    'சந் + செவ் + சனி',
    'சந் + செவ் + ரா',
    'சந் + செவ் + கே',
    'சந் + புத + குரு',
    'சந் + புத + சுக்',
    'சந் + புத + சனி',
    'சந் + புத + ரா',
    'சந் + புத + கே',
    'சந் + குரு + சுக்',
    'சந் + குரு + சனி',
    'சந் + குரு + ரா',
    'சந் + குரு + கே',
    'சந் + சுக் + சனி',
    'சந் + சுக் + ரா',
    'சந் + சுக் + கே',
    'சந் + சனி + ரா',
    'சந் + சனி + கே',
    'செவ் + புத + குரு',
    'செவ் + புத + சுக்',
    'செவ் + புத + சனி',
    'செவ் + புத + ரா',
    'செவ் + புத + கே',
    'செவ் + குரு + சுக்',
    'செவ் + குரு + சனி',
    'செவ் + குரு + ரா',
    'செவ் + குரு + கே',
    'செவ் + சுக் + சனி',
    'செவ் + சுக் + ரா',
    'செவ் + சுக் + கே',
    'செவ் + சனி + ரா',
    'செவ் + சனி + கே',
    'புத + குரு + சுக்',
    'புத + குரு + சனி',
    'புத + குரு + ரா',
    'புத + குரு + கே',
    'புத + சுக் + சனி',
    'புத + சுக் + ரா',
    'புத + சுக் + கே',
    'புத + சனி + ரா',
    'புத + சனி + கே',
    'குரு + சுக் + சனி',
    'குரு + சுக் + ரா',
    'குரு + சுக் + கே',
    'குரு + சனி + ரா',
    'குரு + சனி + கே',
    ' சுக் + சனி + ரா',
    ' சுக் + சனி + கே',
    'சனி + ரா + கே',
  ];

  @override
  void initState() {
    super.initState();
    _selectedComboNotifier = widget.notifier;

    if (_selectedComboNotifier.value == null ||
        _selectedComboNotifier.value!.trim().isEmpty) {
      _selectedComboNotifier.value = 'சூரி+ சந்';
    }
  }

  Stream<QuerySnapshot> _getFirestoreStream(String selected) {
    final isTwo = twoCombinations.contains(selected);
    return FirebaseFirestore.instance
        .collection(isTwo ? 'twocombination' : 'threecombination')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: CustomGradientAppBar(
        title: "கிரக சேர்க்கை",
        onBack: () => Navigator.pop(context),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final availableWidth = constraints.maxWidth;
          final dropdownHorizontalPadding = availableWidth * 0.1;
          final topSpacing = screenHeight * 0.05;

          return Container(
            color: Colors.white,
            padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
            child: Column(
              children: [
                SizedBox(height: topSpacing),
                _buildDropdownWithCountBadge(
                  dropdownHorizontalPadding,
                  availableWidth,
                  screenHeight,
                ),
                SizedBox(height: screenHeight * 0.01),
                Expanded(child: _buildDataTable()),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildDropdownWithCountBadge(
    double horizontalPadding,
    double width,
    double height,
  ) {
    final combinationList = [...twoCombinations, ...threeCombinations];

    return ValueListenableBuilder<String?>(
      valueListenable: _selectedComboNotifier,
      builder: (context, selectedCombo, _) {
        final isTwo = twoCombinations.contains(selectedCombo);
        final key = isTwo ? 'two' : 'three';
        final collection = isTwo ? 'twocombination' : 'threecombination';

        return StreamBuilder<QuerySnapshot>(
          stream:
              FirebaseFirestore.instance
                  .collection(collection)
                  .orderBy('timestamp')
                  .snapshots(),
          builder: (context, snapshot) {
            int count = 0;
            if (snapshot.hasData && selectedCombo != null) {
              count =
                  snapshot.data!.docs
                      .where(
                        (doc) =>
                            (doc.data() as Map<String, dynamic>)[key] ==
                            selectedCombo,
                      )
                      .length;
            }

            return Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(left: horizontalPadding),
                    child: StyledDropdown(
                      selectedValue: _selectedComboNotifier,
                      items: combinationList,
                      hintText: "கிரகக் கூட்டை தேர்வு செய்க",
                    ),
                  ),
                ),
                SizedBox(width: width * 0.05),
                _buildCountBadge(count, height, width),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildCountBadge(int count, double screenHeight, double screenWidth) {
    return Transform.translate(
      offset: Offset(0, -screenHeight * 0.03),
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.04,
          vertical: screenHeight * 0.01,
        ),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF3E0),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.orange.withOpacity(0.3),
              blurRadius: 6,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(
              Icons.list_alt_rounded,
              color: Color(0xFFE65100),
              size: 20,
            ),
            SizedBox(width: screenWidth * 0.015),
            Text(
              "$count",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: screenWidth * 0.045,
                color: const Color(0xFFBF360C),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDataTable() {
    return ValueListenableBuilder<String?>(
      valueListenable: _selectedComboNotifier,
      builder: (context, selectedCombo, _) {
        if (selectedCombo == null) {
          return const Center(
            child: Text(
              "முதலில் ஒரு கிரகக் கூட்டைத் தேர்ந்தெடுக்கவும்.",
              style: TextStyle(fontSize: 16),
            ),
          );
        }

        final isTwo = twoCombinations.contains(selectedCombo);
        final key = isTwo ? 'two' : 'three';
        final collection = isTwo ? 'twocombination' : 'threecombination';

        return StreamBuilder<QuerySnapshot>(
          stream:
              FirebaseFirestore.instance
                  .collection(collection)
                  .orderBy('timestamp')
                  .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(child: Text('பிழை: ${snapshot.error}'));
            }
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }

            final filteredDocs =
                snapshot.data!.docs.where((doc) {
                  return (doc.data() as Map<String, dynamic>)[key] ==
                      selectedCombo;
                }).toList();

            return CommonNotesTable(
              docs: filteredDocs,
              selectedValue: selectedCombo,
              filterKey: key,
              defaultLabel: "கிரகக் கூட்டம்",
            );
          },
        );
      },
    );
  }
}
