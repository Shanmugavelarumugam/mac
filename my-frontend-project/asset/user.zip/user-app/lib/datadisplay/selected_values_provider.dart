class SelectedValues {
  String? lagnam;
  String? bhavam;
  String? planet;
  String? star;
  String? rasi;
  String? combination;
}
