import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:usertest/rowdisp.dart';
import 'package:intl/intl.dart';

class BookmarksScreen extends StatelessWidget {
  const BookmarksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        title: const Text("Bookmarks", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.deepOrange,
        centerTitle: true,
        elevation: 3,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream:
            FirebaseFirestore.instance
                .collection('bookmarks')
                .where('uid', isEqualTo: uid)
                .orderBy('timestamp', descending: true)
                .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const Center(child: Text("❌ Error loading bookmarks"));
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final bookmarks = snapshot.data!.docs;

          if (bookmarks.isEmpty) {
            return const Center(
              child: Text(
                "No bookmarks found.",
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: bookmarks.length,
            itemBuilder: (context, index) {
              final doc = bookmarks[index];
              final data = doc.data() as Map<String, dynamic>;

              final lagnam = data['lagnam'] ?? '';
              final bhavam = data['bhavam'] ?? '';
              final planet = data['planet'] ?? '';
              final rasi = data['rasi'] ?? '';
              final star = data['star'] ?? '';
              final combined = data['combined'] ?? '';
              final bookmarkName = data['bookmarkName'] ?? '';
              final timestamp = (data['timestamp'] as Timestamp?)?.toDate();

              return Container(
                margin: const EdgeInsets.only(bottom: 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFFF3E0), Color(0xFFFFE0B2)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.deepOrange.withOpacity(0.2),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: ListTile(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    vertical: 12,
                    horizontal: 20,
                  ),
                  leading: const Icon(Icons.bookmark, color: Colors.deepOrange),
                  title: Text(
                    bookmarkName.isNotEmpty
                        ? bookmarkName
                        : "$lagnam • $bhavam • $planet",
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 8),
                      if (lagnam.isNotEmpty) _buildLabel("லக்னம்", lagnam),
                      if (bhavam.isNotEmpty) _buildLabel("பாவம்", bhavam),
                      if (planet.isNotEmpty) _buildLabel("கிரகம்", planet),
                      if (rasi.isNotEmpty) _buildLabel("ராசி", rasi),
                      if (star.isNotEmpty) _buildLabel("நட்சத்திரம்", star),
                      if (combined.isNotEmpty)
                        _buildLabel("கிரக சேர்க்கை", combined),
                    ],
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                    tooltip: "Delete",
                    onPressed: () => _confirmDelete(context, doc.id),
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder:
                            (_) => CombinedDisplayScreen(
                              initialLagnam: lagnam,
                              initialBhavam: bhavam,
                              initialPlanet: planet,
                              initialRasi: rasi,
                              initialStar: star,
                              initialCombine: combined,
                            ),
                      ),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildLabel(String title, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 2),
      child: Text(
        "$title: $value",
        style: TextStyle(
          color: Colors.brown.shade700,
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext context, String docId) {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text("Delete Bookmark"),
            content: const Text(
              "Are you sure you want to delete this bookmark?",
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Cancel"),
              ),
              ElevatedButton.icon(
                icon: const Icon(Icons.delete),
                label: const Text("Delete"),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                ),
                onPressed: () async {
                  Navigator.pop(context);
                  await FirebaseFirestore.instance
                      .collection('bookmarks')
                      .doc(docId)
                      .delete();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Bookmark deleted")),
                  );
                },
              ),
            ],
          ),
    );
  }
}
