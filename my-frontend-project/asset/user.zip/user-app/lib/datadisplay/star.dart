import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/dashboard/dashboard.dart';
import 'package:usertest/allbuttons/common_notes_table.dart';
import 'package:usertest/allbuttons/dropdown.dart';
import 'package:usertest/widgets/CustomGradientAppBar.dart';

class Stardisplay extends StatefulWidget {
  const Stardisplay({Key? key}) : super(key: key);

  @override
  _StardisplayState createState() => _StardisplayState();
}

class _StardisplayState extends State<Stardisplay> {
  final ValueNotifier<String?> _selectedStarNotifier = ValueNotifier("அஷ்வினி");

  final List<String> _starList = [
    "அஷ்வினி",
    "பரணி",
    "கார்த்திகை",
    "ரோகிணி",
    "மிருகசீரிடம்",
    "திருவாதிரை",
    "புனர்பூசம்",
    "பூசம்",
    "ஆயில்யம்",
    "மகம்",
    "பூரம்",
    "உத்திரம்",
    "ஹஸ்தம்",
    "சித்திரை",
    "சுவாதி",
    "விசாகம்",
    "அனுஷம்",
    "கேட்டை",
    "மூலம்",
    "பூராடம்",
    "உத்திராடம்",
    "திருவோணம்",
    "அவிட்டம்",
    "சதயம்",
    "பூரட்டாதி",
    "உத்திரட்டாதி",
    "ரேவதி",
  ];

  Stream<QuerySnapshot> _getStarStream() {
    return FirebaseFirestore.instance
        .collection('star')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  void dispose() {
    _selectedStarNotifier.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;
    final horizontalPadding =
        screenWidth > 600 ? screenWidth * 0.1 : screenWidth * 0.04;
    final topSpacing = screenHeight * 0.04;
    return Scaffold(
      appBar: CustomGradientAppBar(
        title: "நட்சத்திரம்",
        onBack: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const HomePage()),
          );
        },
      ),
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            return Container(
              color: Colors.white,
              padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
              child: Column(
                children: [
                  SizedBox(height: topSpacing + 20),
                  _buildDropdownWithCountBadge(
                    screenHeight,
                    screenWidth,
                    screenWidth,
                  ),
                  SizedBox(height: screenHeight * 0.00),
                  Expanded(
                    child: SingleChildScrollView(child: _buildDataTable()),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildDropdownWithCountBadge(
    double width,
    double height,
    double screenWidth,
  ) {
    return ValueListenableBuilder<String?>(
      valueListenable: _selectedStarNotifier,
      builder: (context, selectedStar, _) {
        return StreamBuilder<QuerySnapshot>(
          stream: _getStarStream(),
          builder: (context, snapshot) {
            int count = 0;
            if (snapshot.hasData && selectedStar != null) {
              count =
                  snapshot.data!.docs.where((doc) {
                    return (doc.data() as Map<String, dynamic>)['rasi'] ==
                        selectedStar;
                  }).length;
            }

            return Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.only(left: width * 0.04),
                    child: StyledDropdown(
                      selectedValue: _selectedStarNotifier,
                      items: _starList,
                      hintText: "நட்சத்திரத்தைத் தேர்ந்தெடுக்கவும்",
                    ),
                  ),
                ),
                SizedBox(width: width * 0.05),
                _buildCountBadge(count, height, screenWidth),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildCountBadge(int count, double screenHeight, double screenWidth) {
    return Transform.translate(
      offset: Offset(0, -screenHeight * 0.06),
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: screenWidth * 0.04,
          vertical: screenHeight * 0.01,
        ),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF3E0),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.orange.withOpacity(0.3),
              blurRadius: 6,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(
              Icons.list_alt_rounded,
              color: Color(0xFFE65100),
              size: 20,
            ),
            SizedBox(width: screenWidth * 0.015),
            Text(
              "$count",
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: screenWidth * 0.045,
                color: const Color(0xFFBF360C),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDataTable() {
    return ValueListenableBuilder<String?>(
      valueListenable: _selectedStarNotifier,
      builder: (context, selectedStar, _) {
        if (selectedStar == null) {
          return const Center(
            child: Text(
              "முதலில் ஒரு நட்சத்திரத்தைத் தேர்ந்தெடுக்கவும்.",
              style: TextStyle(fontSize: 16),
            ),
          );
        }

        return StreamBuilder<QuerySnapshot>(
          stream: _getStarStream(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Center(child: Text('பிழை: ${snapshot.error}'));
            }
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }

            final filteredDocs =
                snapshot.data!.docs.where((doc) {
                  return (doc.data() as Map<String, dynamic>)['rasi'] ==
                      selectedStar;
                }).toList();

            if (filteredDocs.isEmpty) {
              return Center(
                child: Text(
                  "தேர்ந்தெடுக்கப்பட்ட நட்சத்திரத்திற்கு எதுவும் கிடைக்கவில்லை.",
                ),
              );
            }

            return CommonNotesTable(
              docs: filteredDocs,
              selectedValue: selectedStar,
              filterKey: 'rasi',
              defaultLabel: "நட்சத்திரம்",
            );
          },
        );
      },
    );
  }
}
