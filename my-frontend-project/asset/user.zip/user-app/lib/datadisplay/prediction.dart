import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:usertest/dashboard/dashboard.dart';

class Prediction extends StatefulWidget {
  @override
  _PredictionDisplayState createState() => _PredictionDisplayState();
}

class _PredictionDisplayState extends State<Prediction> {
  Stream<QuerySnapshot> _getPredictionStream() {
    return FirebaseFirestore.instance
        .collection('prediction')
        .orderBy('timestamp')
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
    leading: IconButton(
      icon: Icon(Icons.arrow_back),
      onPressed: () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomePage()), // Replace with your actual dashboard widget
        );
      },
    ),
    
  ),
      backgroundColor: Colors.white,
      body: Container(
        margin: const EdgeInsets.all(16.0),
        padding: const EdgeInsets.all(16.0),
        child: _buildTable(),
      ),
    );
  }

  Widget _buildTable() {
    return StreamBuilder<QuerySnapshot>(
      stream: _getPredictionStream(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('பிழை: ${snapshot.error}'));  // Error message in Tamil
        }
        if (!snapshot.hasData) {
          return Center(child: CircularProgressIndicator());
        }

        final docs = snapshot.data!.docs;

        if (docs.isEmpty) {
          return Center(child: Text("குறிப்புகள் எதுவும் கிடைக்கவில்லை."));  // "No notes found" in Tamil
        }

        return ListView(
          children: [
            Table(
              columnWidths: const {
                0: IntrinsicColumnWidth(),
                1: FlexColumnWidth(),
              },
              border: TableBorder.all(color: Colors.black26),
              children: [
                TableRow(
                  decoration: BoxDecoration( color: const Color.fromARGB(255, 229, 188, 127),),
                  children: [
                    Padding(
                      padding: EdgeInsets.all(4.5),
                      child: Text(
                        "எண்",  // "S.No" in Tamil
                        style: TextStyle(fontWeight: FontWeight.bold, color: Colors.deepOrange),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(4.5),
                      child: Text(
                        "பரிகா",  // "Parvai" (Prediction) in Tamil
                        style: TextStyle(fontWeight: FontWeight.bold, color: Colors.deepOrange),
                      ),
                    ),
                  ],
                ),
                ...docs.asMap().entries.map((entry) {
                  final index = entry.key + 1;
                  final data = entry.value.data() as Map<String, dynamic>;
                  final prediction = data['prediction'] ?? '';

                  return TableRow(
                    children: [
                      Padding(
                        padding: EdgeInsets.all(4.5),
                        child: Text(index.toString(), style: TextStyle(color: Colors.white)),
                      ),
                      Padding(
                        padding: EdgeInsets.all(4.5),
                        child: Text(prediction, style: TextStyle(color: Colors.black)),
                      ),
                    ],
                  );
                }).toList(),
              ],
            ),
          ],
        );
      },
    );
  }
}
