import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class CommonNotesTable extends StatelessWidget {
  final List<QueryDocumentSnapshot> docs;
  final String? selectedValue;
  final String filterKey;
  final String defaultLabel;

  const CommonNotesTable({
    super.key,
    required this.docs,
    required this.selectedValue,
    required this.filterKey,
    this.defaultLabel = "மேஷம் லக்னம்",
  });

  @override
  Widget build(BuildContext context) {
    final filteredDocs =
        selectedValue == defaultLabel
            ? docs
            : docs
                .where(
                  (doc) =>
                      (doc.data() as Map<String, dynamic>)[filterKey] ==
                      selectedValue,
                )
                .toList();

    if (filteredDocs.isEmpty) {
      return const Center(
        child: Text(
          "தேர்ந்தெடுக்கப்பட்ட லக்னத்திற்கான குறிப்புகள் இல்லை.",
          style: TextStyle(fontSize: 16),
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: SingleChildScrollView(
              child: Table(
                columnWidths: const {
                  0: FixedColumnWidth(50),
                  1: FlexColumnWidth(),
                },
                border: TableBorder.symmetric(
                  inside: const BorderSide(width: 0.3, color: Colors.black),
                  outside: const BorderSide(
                    width: 1.0,
                    color: Color(0xFFF4673C),
                  ),
                ),
                children: [
                  TableRow(
                    decoration: const BoxDecoration(color: Color(0xFFF4673C)),
                    children: [
                      _tableHeaderCell("#"),
                      _tableHeaderCell(selectedValue ?? defaultLabel),
                    ],
                  ),
                  ...filteredDocs.asMap().entries.map((entry) {
                    final index = entry.key + 1;
                    final data = entry.value.data() as Map<String, dynamic>;
                    final notes = data['notes'] ?? '';
                    final isEven = index % 2 == 0;

                    return TableRow(
                      decoration: BoxDecoration(
                        color: isEven ? Colors.grey[100] : Colors.white,
                      ),
                      children: [
                        _tableCell(index.toString(), isIndex: true),
                        _tableCell(notes),
                      ],
                    );
                  }).toList(),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _tableHeaderCell(String text) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Center(
        child: Text(
          text,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontSize: 16,
          ),
        ),
      ),
    );
  }

  Widget _tableCell(String text, {bool isIndex = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      child: Text(
        text,
        softWrap: true,
        textAlign: isIndex ? TextAlign.center : TextAlign.left,
        style: TextStyle(
          fontSize: 15,
          fontWeight: isIndex ? FontWeight.w600 : FontWeight.normal,
          color: isIndex ? const Color(0xFFF4673C) : Colors.black87,
        ),
      ),
    );
  }
}
