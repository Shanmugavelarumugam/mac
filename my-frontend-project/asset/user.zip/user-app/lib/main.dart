import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:usertest/dashboard/dashboard.dart';
import 'package:usertest/firebase_options.dart';
import 'package:usertest/login/login.dart';
import 'package:usertest/login/shared_preferences.dart';
import 'package:usertest/register/register.dart';
import 'package:usertest/research/basic_info_screen.dart';
import 'package:usertest/research/child_screen.dart';
import 'package:usertest/research/death_screen.dart';
import 'package:usertest/research/education_screen.dart';
import 'package:usertest/research/health_screen.dart';
import 'package:usertest/research/job_screen.dart';
import 'package:usertest/research/marriage_screen.dart';
import 'package:usertest/research/research_complete_screen.dart';
import 'package:usertest/research/research_screen.dart';
import 'package:usertest/widgets/text.dart';
import 'package:firebase_auth/firebase_auth.dart';  

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  SharedPreferences prefs = await SharedPreferences.getInstance();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
      routes: {
        '/research': (context) => const ResearchScreen(),

        '/basic': (context) => const BasicInfoScreen(),
        '/marriage': (context) => const MarriageScreen(),
        '/job': (context) => const JobScreen(), // create this next
        '/education': (context) => const EducationScreen(),
        '/health': (context) => const HealthScreen(),
        '/child': (context) => const ChildScreen(),
        '/death': (context) => const DeathScreen(),
        '/complete': (context) => const ResearchCompleteScreen(),
      },
    );
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkUserStatus();
  }

  Future<void> _checkUserStatus() async {
    String? token = await AuthTokenStorage.getToken();

    Timer(const Duration(seconds: 3), () {
      if (token == null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const HomePage()),
        );
      } else {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomePage()),
        );
      }
    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Astro(),
      ),
    );
  }
}
